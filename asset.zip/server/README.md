### 1. Create a service file with name as starapp.service in the folder /lib/systemd/system directory with following contents
        [Unit]
        Description=Star App API Service
        After=network-online.target

        [Service]
        WorkingDirectory=/opt/star_app/server/
        User=root
        ExecStart=/usr/bin/npm run start
        Restart=on-failure
        Environment=LD_LIBRARY_PATH=/usr/lib/oracle/18.3/client64/lib
        StandardOutput=syslog
        StandardError=syslog
        SyslogIdentifier=starapp
        [Install]
        WantedBy=multi-user.target

### 2. Now run the following command 
        systemctl daemon-reload
        systemctl restart starapp
        systemctl status starapp

### 3. To enable logging to a directory create a file starapp.conf in the location /etc/rsyslog.d/ with the content as 
        if $programname == 'starapp' then /var/log/starapp.log
        & stop

### 4. Restart the service rsyslog using the following command
        systemctl restart rsyslog

### 5. Restart the application starapp after restarting the rsyslog service 
        systemctl restart starapp
