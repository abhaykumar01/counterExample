#!/bin/bash

ansible-vault decrypt $1 --vault-password-file=vaultkeyfile
