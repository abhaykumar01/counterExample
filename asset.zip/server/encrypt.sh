#!/bin/bash

ansible-vault encrypt $1 --vault-password-file=vaultkeyfile
