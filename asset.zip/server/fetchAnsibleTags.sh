out=`ansible-playbook --list-tags $1 2>&1`
status=$?
if [ "$status" -ne "0" ]; then
    echo "$out"
    exit 1
  else
    echo "$out" | grep -e "TASK TAGS" | cut -d":" -f2 | awk '{sub(/\[/, "")sub(/\]/, "")}1' | sed -e 's/,//g' | xargs -n 1 | sort -u | sed -z 's/\n/,/g' | sed 's/,$//'
    exit 0
fi 
