#!/bin/bash

mailSubject="$1 : $3 : $2"

mail -s "$mailSubject" -a $4 $5 << EOF

EXECUTED BY: $5
DATE AND TIME: `date`

TARGET ENVIRONMENT: $3
EOF