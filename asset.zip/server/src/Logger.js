const {transports, createLogger, format}  = require('winston');

var __dirname = `${process.env.NODE_STAR_LOGS_DIR}`


const logger =(tcrno,curtime) => createLogger({
    	format: format.combine(
    	format.timestamp(),
	format.json()	
   ), 
	transports: [
      //
      // - Write to all logs with level `info` and below to `combined.log` 
      // - Write all logs error (and below) to `error.log`.
      //
	new transports.File({ filename: `${__dirname}/${tcrno}_${curtime}.err.log`, level: 'error' }),
      new transports.File({ filename: `${__dirname}/${tcrno}_${curtime}.log`})
    ]
  });
   

module.exports = logger;
