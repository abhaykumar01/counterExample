const encrypt = require("child_process").exec;

const vault = ( script ) =>  encrypt(script
    ,
   (error, stdout, stderr) => {
 console.log('inside vault file');
   console.log(stdout);
   console.log(stderr);
   if (error !== null) {
     console.log(`exec error: ${error}`);
   }
 }
);


module.exports = {
    vault
};
