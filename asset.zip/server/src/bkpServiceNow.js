const axios = require("axios");
const { getRepositoryPath } = require("./util");
const { checkout } = require("./SVNService");
const pubsub = require("./pubsub");
const executePlaybook = require("./AnsibleService");
const logger = require("./Logger");
const { sendEmail } = require("./util");
const { addNotifier } = require("./util");

const instance = axios.create({
  baseURL: "https://rbos.service-now.com/api",
  timeout: 3000,
  headers: {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    Authorization:
      "Basic " +
      Buffer.from("API-ftcm" + ":" + "Cu=5BlC5IV+#Ek&S6*no").toString("base64"),
    "Access-Control-Allow-Headers":
      "Origin, X-Requested-With, Content-Type, Accept"
  }
});


const getServiceNowInfo = async ( tcrno, env, action, application) => {
  try {

console.log('in servicenow',env);
const curtime = Date.now();
console.log('-------------------CURTIME--------',curtime);

const log = logger(tcrno,curtime);
    log.log({
      level: "info",
      message: `Logging started for ${tcrno}.`
    });

	log.log("info",`Action request: ${action}`);
	log.log("info",`Environment: ${env}`);

    const uristring = `/now/table/change_request?sysparm_query=number=${tcrno}&sysparm_fields=parent%2Cu_mcr_state%2Cstate%2Cstart_date%2Cimplementation_plan%2Cu_change_raiser%2Cend_date%2Ccmdb_ci%2Cu_affected_service%2Cassigned_to%2Cassignment_group`;
    
    const data = await instance.get(uristring);
    
	const result = data.data.result[0];
	let responses = [];

    if (result) {
      const repository = getRepositoryPath(result.implementation_plan);
      const emails = addNotifier(result.implementation_plan);

      const response = {
        message: `TCR No: ${tcrno} is validated`,
        error: [],
        tcrno
      };
      responses = [...responses, response];
      pubsub.publish("TCR_PROCESSING", {
        tcrProcessing: responses
      });

      console.log("New response have been published: ");
     
	log.log("info",`TCR No: ${tcrno} is validated.`);

//	const email = sendEmail(`sh {process.env.NODE_APP_HOME}sendmail.sh  /export/home/rmadmin/deploy_ansible/logs/${tcrno}${curtime}.log ${records.assignee_info.email}`);
 
      const mcr = await getMCRInfo(result.parent.value);
      const change_raiser = await getChangeRaiser(result.u_change_raiser.value);
      const assignment_team = await getAssignmentTeam(
        result.assignment_group.value
      );
      const assignee_info = await getAssigneeInfo(result.assigned_to.value);
      const affected_service = await getAffectedService(
        result.u_affected_service.value
      );

     
      const records = {
        mcr: { ...mcr, state: result.u_mcr_state },
        tcr: { state: result.state, number: tcrno },
        repository: repository,
	emails,
        assignment_team,
        assignee_info,
        change_raiser,
        affected_service
      };
    //Here we are going to check whether the affected_service is same as the application name sent by the user
      
	if(affected_service.name !== application){
        console.log('---affected_service --',affected_service);
        console.log('---application --',application);
        console.log('----User does not have permission to execute task for this application');
        responses = [
          ...responses,
          {
            message: "",
            error: [`Affected service ${application} is not mapped with the provided tcr no: ${tcrno}`],
            tcrno
          }
        ];
        pubsub.publish("TCR_PROCESSING", {
          tcrProcessing: responses
        });
        return records;
      }
      else{
        console.log('----affected service is same as applicaiton')
      }

      console.log("---records----", records);
      responses = [
        ...responses,
        {
          message: "Going to checkout Repository",
          error: [],
          tcrno
        }
      ];
      pubsub.publish("TCR_PROCESSING", {
        tcrProcessing: responses
      });

	log.log("info",`TCR Status: ${result.state}`);
        log.log("info",`MCR: ${mcr.number}`);
	log.log("info",`MCR Status: ${mcr.state}`);		
	log.log("info",`Starting checkout to Repository: ${repository.repo_path}`);
	log.log("info",`Repository Path version is: ${repository.repo_revision}`);
//	records.assignee_info.email = amarinderpal.singh@rbs.com;


      const status = await checkout(repository, tcrno,env,action, responses, curtime, records);

      return records;
    } else {
	log.log("error",`TCR No: ${tcrno} is invalid`);

	responses = [
          ...responses,
          {
            message: "",
            error: [`tcr no: ${tcrno} is not valid`],
            tcrno
          }
        ];
        pubsub.publish("TCR_PROCESSING", {
          tcrProcessing: responses
        });
	
      
	const email = sendEmail(`sh ${process.env.NODE_APP_HOME}/sendmail.sh Failure ${tcrno} ${records.mcr.number} ${records.mcr.state} ${records.tcr.state} ${records.repository.repo_path} ${records.repository.repo_revision} /export/home/rmadmin/deploy_ansible/logs/${tcrno}_${curtime}.log ${records.assignee_info.email}`); 
	console.error(`TCR No ${tcrno} is invalid`);
      return { error: `TCR No ${tcrno} is invalid` };
    }
  } catch (error) {

	 responses = [
          ...responses,
          {
            message: "",
            error: [`tcr no: ${tcrno} is not valid`],
            tcrno
          }
        ];
        pubsub.publish("TCR_PROCESSING", {
          tcrProcessing: responses
        });

    console.log("error 123 ---", error);
    console.log(`error4545: ${error.error}`);
    log.log("error",`Error Fetching the Information for ${tcrno} `);
    log.log("error",`${error}`);
   
	const email = sendEmail(`sh ${process.env.NODE_APP_HOME}/sendmail.sh Failure ${tcrno} ${records.mcr.number} ${records.mcr.state} ${records.tcr.state} ${records.repository.repo_path} ${records.repository.repo_revision} /export/home/rmadmin/deploy_ansible/logs/${tcrno}_${curtime}.log ${records.assignee_info.email}`); 

  // const email = sendEmail(`sh {process.env.NODE_APP_HOME}sendmail.sh Failure ${tcrno} 1 1 1 1 1 /export/home/rmadmin/deploy_ansible/logs/${tcrno}_${curtime}.log kanika.khurana@rbs.com`);
 
	throw new Error({ error: `Error Fetching the Information for ${tcrno} ` });
  }
};


const getMCRInfo = async parent => {
  console.log("---In getMCRInfo ---", parent);
  const uristring = `/now/table/task?sysparm_query=sys_id=${parent}&sysparm_fields=number`;
  //console.log(`uristring: ${uristring}`);
  try {
    const mcrinfo = await instance.get(uristring);
    //  console.log('---mcrinfo---', mcrinfo.data.result);
    let mcrnumber = mcrinfo.data.result;
    return mcrnumber[0] || {};
	log.log("info",`MCR: ${mcrnumber}`);
  } catch (error) {
	log.log("error",`Error while fetching MCR information for: ${mcrnumber}` );
       const email = sendEmail(`sh ${process.env.NODE_APP_HOME}/sendmail.sh Failure ${tcrno} ${records.mcr.number} ${records.mcr.state} ${records.tcr.state} ${records.repository.repo_path} ${records.repository.repo_revision} /export/home/rmadmin/deploy_ansible/logs/${tcrno}_${curtime}.log ${records.assignee_info.email}`); 
	console.error(
      `Error while fetching MCR information for parent ${parent} : `,
      error
    );
  }
  return {};
};

const getAssigneeInfo = async assignee_id => {
  console.log("---In getAssigneeInfo ---", assignee_id);
  const uristring = `/now/table/sys_user?sysparm_query=sys_id=${assignee_id}&sysparm_fields=u_full_name%2Cemail`;
  //  console.log(`uristring: ${uristring}`);
  try {
    const assignee = await instance.get(uristring);
    //  console.log('---assignee---', assignee.data.result);
    let assignee_info = assignee.data.result;
    return assignee_info[0] || {};
  } catch (error) {
	log.log("error",`Error while fetching Assignee information for: ${assignee_id}` );

    console.error(
      `Error while fetching Assignee information for change assignee id  ${assignee_id} : `,
      error
    );
  }
  return {};
};

const getAssignmentTeam = async assignmentTeam => {
  console.log("---In getAssignmentTeam ---", assignmentTeam);
  const uristring = `/now/table/sys_user_group?sysparm_query=sys_id=${assignmentTeam}&sysparm_fields=name`;
  // console.log(`uristring: ${uristring}`);
  try {
    const assignment_team = await instance.get(uristring);
    //   console.log('---assignment_team---', assignment_team.data.result);
    let assignment_team_info = assignment_team.data.result;
    return assignment_team_info[0] || {};
  } catch (error) {
	log.log("error",`Error while fetching Assignment Team information for: ${assignmentTeam}`);
    console.error(
      `Error while fetching Assignmet Team information for change assignmentTeam  ${assignmentTeam} : `,
      error
    );
  }
  return {};
};

const getChangeRaiser = async change_raiser_id => {
  console.log("---In getChangeRaiser ---", change_raiser_id);
  const uristring = `/now/table/sys_user?sysparm_query=sys_id=${change_raiser_id}&sysparm_fields=u_full_name%2Cemail`;
  //console.log(`uristring: ${uristring}`);
  try {
    const change_raiser = await instance.get(uristring);
    // console.log('---change_raiser---', change_raiser.data.result);
    let change_raiser_info = change_raiser.data.result;
    return change_raiser_info[0] || {};
  } catch (error) {
	log.log("error",`Error while fetching Change Raiser information for change raiser id  ${change_raiser_id}` );

    console.error(
      `Error while fetching Change Raiser information for change raiser id  ${change_raiser_id} : `,
      error
    );
  }
  return {};
};

const getAffectedService = async affectedservice => {
  console.log("---In getAffectedService ---", affectedservice);
  const uristring = `/now/table/cmdb_ci?sysparm_query=sys_id=${affectedservice}&sysparm_fields=name`;
  //console.log(`uristring: ${uristring}`);
  try {
    const affected_service = await instance.get(uristring);
    console.log('---affected_service-656565--', affected_service.data.result);
    let affected_service_info = affected_service.data.result;
    return affected_service_info[0] || {};
  } catch (error) {
	log.log("error",`Error while fetching Affected Service information for affected service :${affectedservice}`);	
    console.error(
      `Error while fetching Affected Service information for affected service  ${affectedservice} : `,
      error
    );
  }
  return {};
};

module.exports = {
  getMCRInfo,
  getAssigneeInfo,
  getAssignmentTeam,
  getChangeRaiser,
  getAffectedService,
  getServiceNowInfo
};

