module.exports = {
    secretOrKey: "secret",
    srcUserName: "agniha",
    srcPassword: "Welcome4"
};
