var moment = require('moment');

var start_date = '2019-11-06 00:00:00';
var end_date = '2019-11-08 00:00:00';

const validateDate = (start_date,end_date) =>
{
        var nowDate = new Date();
        var currentDate = moment(nowDate).format("YYYY-MM-DD HH:mm:ss");

        var mstartDate = moment(start_date);
        var mendDate = moment(end_date);

console.log('In Validate Function');
console.log(currentDate,'currentDate');
console.log(start_date,'start_date');
console.log(end_date,'end_date');
        if (moment(currentDate).isBetween(mstartDate,mendDate)) {
        console.log('Date validated');
        }
        else {
        console.log('InValid Date');
        }
}



var d1 = '2019-11-06 00:00:00';
var d2 = '2019-11-08 00:00:00';

//var UTCstring = (new Date()).toUTCString();


//var dt = '2019-11-07 00:00:00';
var dt = new Date();
var dt2 = moment(dt);

console.log('dt2',dt2);
console.log('d1',d1);
console.log('d2',d2);

var md1 = moment(d1);
console.log('md1', md1);

var md2 = moment(d2);
console.log('md2',md2);

if (moment(dt2).isBetween(md1,md2)) {
console.log('true');
}
else {
console.log('false');
}


var status =  'Scheduled';
if (status === 'Schedul'){
console.log('true');
}
else
{
console.log('fallll');
}
