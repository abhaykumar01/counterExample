const oracledb = require('oracledb');
const dbConfig = require('./dbconfig');

oracledb.autoCommit = true; 

const getConnection = async () => {
  // console.log('---Environment value ----',process.env);
  try{
    let connection = await oracledb.getConnection(dbConfig);
    console.log('---Connection was successfull123----');
    return connection;
  }catch(error){
    console.error('---Connection was not successful----',error);
  }
  return null;
}

const closeConnection = async (dbconnection) => {
    if(dbconnection){
      try{
        await dbconnection.close();
      }catch(error){
        console.error('---Error while closing connection---',error);
      }
    }
}

const executeStatement = async (statement, param) => {
  let dbConnection;
  try{
     dbConnection = await getConnection();
    const result = await dbConnection.execute(statement, [param]);
    return result; 
  }catch(error){
    console.error('Error while executing statement: ',error);
    closeConnection(dbConnection)
  } 
  return null;
}

const executeStatementWithObjectParams = async (statement, params) => {
  let dbConnection;
  try{
     dbConnection = await getConnection();
    const result = await dbConnection.execute(statement, {...params});
    return result; 
  }catch(error){
    console.error('Error while executing statement: ',error);
    closeConnection(dbConnection)
  } 
  return null;
}


const execute = async (statement) => {
let dbConnection;
try{
   dbConnection = await getConnection();
   const result = await dbConnection.execute(statement);
   return result;
 }catch(error){
    console.error('Error while executing statement: ',error);
    closeConnection(dbConnection);
 }

}

module.exports = { executeStatement, execute, executeStatementWithObjectParams}

//
