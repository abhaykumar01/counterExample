const {decrypt} = require('../util');
module.exports = {
    user: process.env.NODE_ORACLEDB_USER || 'fingel',
    password: process.env.NODE_ORACLEDB_PASSWORD || 'CEREBELLUM',
    connectString: process.env.NODE_ORACLEDB_CONNECTIONSTRING || "dogb0312"
}

