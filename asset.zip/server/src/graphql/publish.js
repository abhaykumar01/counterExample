const pubsub = require('../pubsub');

const publishResponse = (channel, key, response) => {
    pubsub.publish(channel, {
      [key]: response
    });
}


module.exports = {publishResponse};