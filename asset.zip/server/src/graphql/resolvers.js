
const {getServiceNowInfo} = require('../service/ServiceNow');
const pubsub = require('../pubsub');


const resolvers = {
    Query: {
       
        serviceProcessing:  async (parent, args, context, info) => {
            console.log('---args ----',args);
            const records = await getServiceNowInfo(args.tcrno);
            console.log('---records in resolvers---',records);
            return records;
        },
        tcrQuery:  async (parent, args, context, info) => {
            console.log('---args ----',args);
            const records = {message: 'Initiated request', error: [], tcrno: args.tcrno};
            console.log('---records in tcrquery---',records);
            return records;
        }
    },
    Subscription: {
        tcrProcessing: {
         subscribe:   () => pubsub.asyncIterator('TCR_PROCESSING') 
        },

        checkoutProcessing: {
            subscribe: () => pubsub.asyncIterator('CHECKOUT_PROCESSING')
        },

        healthCheckProcessing: {
            subscribe: () => pubsub.asyncIterator('HEALTH_CHECK_PROCESSING')
        },
        
        tagsProcessing: {
            subscribe: () => pubsub.asyncIterator('TAGS_LIST_AVAILABLE')
        }
    }

}
module.exports = resolvers;