const {gql} = require('apollo-server');

const schema = gql`
 type Response {
     message: String!,
     error: [String],
     tcrno: String!
 }

 type CheckoutResponse {
    message: String!,
    error: [String],
    tcrno: String!,
    svnpath: String!,
    svnrevision: String!
}

type TagsResponse {
    svnrepo: String!,
    svnrevision: String!,
    error: [String],
    tags: [String],
    tcrno: String
}

 type Responses {
     executions: [Response]
 }

 type MCR {
     number: String,
     state: String
 }

 type Repository {
     repo_path: String,
     repo_revision: String
 }

 type TCR {
     number: String,
     state: String
 }

 type AssignmentTeam {
     name: String
 }

 type AssigneeInfo {
     email: String,
     u_full_name: String
 }



 type ProcessingResponse {
     mcr: MCR,
     repository: Repository,
     tcr: TCR,
     assignment_team: AssignmentTeam,
     assignee_info: AssigneeInfo,
     change_raiser: AssigneeInfo,
     affected_service: AssignmentTeam
 }
 
 type Query {
     serviceProcessing(tcrno: String!, env: String, action: String): ProcessingResponse!,
     tcrQuery(tcrno: String!, env: String, action: String): Response!
 }

 type HealthCheck {
    message: [String],
    error: [String],
    tcrno: String!
}


 type Subscription {
     tcrProcessing: Response,
     checkoutProcessing: CheckoutResponse,
     tagsProcessing: TagsResponse,
     healthCheckProcessing: HealthCheck
 }

`

module.exports = schema;