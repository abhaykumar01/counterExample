require('dotenv').config();
const { verifyServersAssociatedWithEnvironment,
    fetchExecutionId,
    fetchExecutionIdFromTCRProcessable,
    updateExecutionStatusTags } = require('../util');
const { fetchAnsibleTags, healthCheck } = require('../service/AnsibleService');
const {
    TCR_PROCESSING_RETRYABLE,
    EXECUTION_SUCCESSFUL,
    TCR_PROCESSING_FREEZED,
    TCR_EXECUTION_IN_PROGRESS,
    EXECUTION_FAILED
} = require('../constant/executionstate');
const { publishResponse } = require('../graphql/publish');

const _ = require('lodash');


// const validateExecutionPossible = async (tcrno, env, sysid, action, revision, repo_path, app) => {
//     //    id, tcrno, status, executed_at, message, execution_code, revision, repo_path, environment, action
//    if (action ==='Deploy') {
//     if(action === action_rec && status === EXECUTION_SUCCESSFUL){
//        res1 = { message: '', error: [`${tcrno} is already executed`], tcrno }
//       publishResponse('TCR_PROCESSING', 'tcrProcessing', res1);
//       return {status: false, execution_id: execution_id, message: `${tcrno} is already executed`};
//      }
//      if(action === action_rec && status === EXECUTION_FAILED && execution_code === TCR_PROCESSING_RETRYABLE){
//       return {status: true, execution_id: execution_id};
//      }
//      if(action === action_rec && status === EXECUTION_FAILED && execution_code === TCR_PROCESSING_FREEZED){
//       res1 = { message: '', error: [`${tcrno} is already executed`], tcrno }
//       publishResponse('TCR_PROCESSING', 'tcrProcessing', res1);
//       return {status: false, execution_id: execution_id, message:`${tcrno} is already executed` };
//      }
//    } else {
//       if(action_rec === 'Deploy' && status === EXECUTION_SUCCESSFUL){
//         return {status: true, execution_id: execution_id};
//      }
//      if(action_rec === 'Deploy' && status === EXECUTION_FAILED){
//       res1 = { message: '', error: [`${tcrno} Rollback not allowed for the Failed Deployments`], tcrno }
//       publishResponse('TCR_PROCESSING', 'tcrProcessing', res1);
//       return {status: false, execution_id: execution_id, message: `${tcrno} Rollback not allowed for the Failed Deployments` };
//    }
//      if(action === action_rec && status === EXECUTION_FAILED && execution_code === TCR_PROCESSING_RETRYABLE){
//       return {status: true, execution_id: execution_id};
//      }
//      if(action === action_rec && status === EXECUTION_FAILED && execution_code === TCR_PROCESSING_FREEZED){
//       res1 = { message: '', error: [`${tcrno} Rollback not allowed for Non Retryable Failed Execution`], tcrno }
//       publishResponse('TCR_PROCESSING', 'tcrProcessing', res1);
//       return {status: false, execution_id: execution_id, message: `${tcrno} Rollback not allowed for Non Retryable Failed Execution`};
//      }
//    }

// }

exports.executeAnsibleTags = async (req, res) => {
    console.log('---  executeAnsibleTags - Parameters -----', req.body);
    console.log('---  executeAnsibleTags - isEnvChecked -----', req.body.isEnvChecked);
    console.log('----request header---', req.headers);
    //tcrno, env, sysid, action, revision, repo_path, app
    const { srcsys, svnrepo, tcrno, action, curtime, tag, app, env, srcrevision } = req.body;
    console.log(`--- executeAnsibleTags - srcsys: ${srcsys}, svnrepo: ${svnrepo}, tcrno: ${tcrno}, tag: ${tag}, env: ${env}, srcrevision: ${srcrevision}  -----`);
    const { sysid, email } = req.headers || 'SYSTEM';

    let clonepath = 'SVNcheckout';

    if (req.body.srcsys === 'git' || req.body.srcsys === 'GIT') {
        clonepath = 'GITclone'
    }
    try {


        //convert the tag which is coming from the UI as array of string to comma separated string for comparison
        let tstrring = ''
        let tagstring = tag.join();

        if (env === 'Production') {
            let exec_records = await fetchExecutionIdFromTCRProcessable(tcrno, env, sysid, action, srcrevision, svnrepo, app);
            if (exec_records !== null) {
                const [execution_id, , status, , message, execution_code, , , , action_rec, tags] = exec_records;
                console.log(`---execution_id: ${execution_id}, status: $
                {status} ,execution_code: ${execution_code} , tags: ${tags}----`);
                let res1 = '';

                console.log(`--tag: ${tagstring}  and tags: ${tags}`);
                if(tags && tags !== null)
                    console.log(`--tag length: ${tagstring.length}  and tags length: ${tags.length}`);
                if (action === 'Deploy') {
                    console.log('--------AnsibleHandler --- DEPLOY Validation -------', action, '--', action_rec, '---status --', status, '---execution-code ---', execution_code);


                    if (action === action_rec && status === EXECUTION_SUCCESSFUL && tags === 'all') {
                        res1 = { message: '', error: [`${tcrno} is already executed for all tags`], tcrno }
                        publishResponse('TCR_PROCESSING', 'tcrProcessing', res1);
                        res.status(500).send(`${tcrno} is already executed for all tags`);
                        return;
                    }

                    if (action === action_rec && status === EXECUTION_SUCCESSFUL && tags !== 'all') {
                        console.log('-------1ST CONDITION------')
                        //condition here is the user might have earlier deployed tags say ['abc', 'cde'] and status is successful. He is now trying to execute the tag
                        // ['abc', 'xyz']. Here one of the tag is executed whereas other one is not executed. So we are going to return the message that the specific tag has been executed already
                     

                        if (tagstring === tags) {
                            console.log('-------2ND CONDITION------');
                            res1 = { message: '', error: [`Tags ${tagstring} is already executed for ${tcrno}`], tcrno }
                            publishResponse('TCR_PROCESSING', 'tcrProcessing', res1);
                            res.status(500).send(`Tags ${tagstring} is already executed for ${tcrno}`);
                            return;
                        } else {
                            console.log('-------3RD CONDITION------')
                            let tags_rec = tags !== null? tags.split(','): [];
                            console.log('---tags_rec  db---', tags_rec);
                            console.log('---tag---', tag);

                           const joinedTag = tag.join();
                           console.log('----joinedTag --------', joinedTag);
                           if (joinedTag === 'all' && tags_rec.length > 0) {
                                res1 = { message: '', error: [`One or all of Tags ${tagstring} is already executed for ${tcrno}`], tcrno }
                                publishResponse('TCR_PROCESSING', 'tcrProcessing', res1);
                                res.status(500).send(`One or all of Tags ${tagstring} is already executed for ${tcrno}`);
                                return;
                           }

                            const intersection = _.intersection(tag, tags_rec);
                            console.log('----intersection------', intersection);
                            if (intersection && intersection.length > 0) {
                                res1 = { message: '', error: [`One or all of Tags ${tagstring} is already executed for ${tcrno}`], tcrno }
                                publishResponse('TCR_PROCESSING', 'tcrProcessing', res1);
                                res.status(500).send(`One or all of Tags ${tagstring} is already executed for ${tcrno}`);
                                return;    
                            } 
                            
                        }


                    }

                    if (action === action_rec && status === EXECUTION_FAILED && execution_code === TCR_PROCESSING_FREEZED) {
                        res1 = { message: '', error: [`${tcrno} is already executed`], tcrno }
                        publishResponse('TCR_PROCESSING', 'tcrProcessing', res1);
                        res.status(500).send(`${tcrno} is already executed`);
                        return;

                    }
                    console.log('--------AnsibleHandler --- DEPLOY Validation DONE -------');
                }
                if (action === 'Rollback') {
                    console.log('--------AnsibleHandler --- ROLLBACK Validation -------');
                    if ((action_rec === '' || action_rec === null) && status === TCR_EXECUTION_IN_PROGRESS) {
                        res1 = { message: '', error: [`${tcrno} Successful deployment required for Rollback`], tcrno }
                        publishResponse('TCR_PROCESSING', 'tcrProcessing', res1);
                        res.status(500).send(`${tcrno} Successful deployment required for Rollback`);
                        return;

                    }

                    if (action_rec === 'Deploy' && status === EXECUTION_FAILED) {
                        res1 = { message: '', error: [`${tcrno} Rollback not allowed for the Failed Deployments`], tcrno }
                        publishResponse('TCR_PROCESSING', 'tcrProcessing', res1);
                        res.status(500).send(`${tcrno} Rollback not allowed for the Failed Deployments`);
                        return;

                    }

                    if (action === action_rec && status === EXECUTION_FAILED && execution_code === TCR_PROCESSING_FREEZED) {
                        res1 = { message: '', error: [`${tcrno} Rollback not allowed for Non Retryable Failed Execution`], tcrno }
                        publishResponse('TCR_PROCESSING', 'tcrProcessing', res1);
                        res.status(500).send(`${tcrno} Rollback not allowed for Non Retryable Failed Execution`);
                        return;
                    }
                    // i am trying to rollback specific tag. Need to check in database record if the tag was successfully deployed or all tag was successully deployed
                    let tagJoined = tag.join();
                    console.log('----tagJoined -------', tagJoined);
                    if (action_rec === 'Deploy' && status === EXECUTION_SUCCESSFUL && tags !=='all' && tagJoined !== 'all' ) {
                        let tags_rec = tags !== null? tags.split(','): [];
                            console.log('---tags_rec rollback  db---', tags_rec);
                            console.log('---tag-rollback--', tag);
                        const diffbetweenUiTagAndDbTag = _.difference(tag, tags_rec );
                        console.log('---diffbetweenUiTagAndDbTag----',diffbetweenUiTagAndDbTag);

                        if(diffbetweenUiTagAndDbTag && diffbetweenUiTagAndDbTag.length > 0){
                            console.log('----diffbetweenUiTagAndDbTag length is > 0----');
                            res1 = { message: '', error: [`${tcrno} Rollback not allowed as some of tag does not have successfull deployment`], tcrno }
                            publishResponse('TCR_PROCESSING', 'tcrProcessing', res1);
                            res.status(500).send(`${tcrno} Rollback not allowed as some of tag does not have successfull deployment`);
                            return;
                        }
                    }

                }
            } else {
                console.log(`error: Execution Record should Exist for this processing`);
                res.status(500).send('No Execution Record found for processing further');
                return;
            }
        }

        const filePath = process.env.NODE_STAR_CHECKOUT_DIR + `/${clonepath}/` + tcrno + "_" + curtime;
        console.log('---POST executeAnsibleTags filePath----', filePath);
        const isServerVerified = await verifyServersAssociatedWithEnvironment(filePath, env, app, tcrno, sysid, action, srcrevision, svnrepo);

        if (isServerVerified !== null) {
            res.status(400).send(isServerVerified);
        }
        console.log('---Going to call the fetchExecutionId from execute ansibleTags -----', svnrepo);
        const exec_rec = await fetchExecutionId(tcrno, env, sysid, action, srcrevision, svnrepo, app);
        console.log('---exec_rec----', exec_rec);

        const result = await healthCheck(exec_rec[0], srcsys, svnrepo, tcrno, action, env, curtime, tag, app, sysid, email);
        console.log('---result after getting healthcheck done ---', result);

        if (result.error) {
            res.status(400).send(result);
        } else {
            res.status(200).send(result);
        }


    } catch (error) {
        console.log(`error: ${error}`);
        res.status(500).send(error);
    }
};

exports.fetchAnsibleTags = async (req, res) => {
    console.log('---request parameters in fetchAnsibleTagsHandler ----', req.body);
    const { sysid } = req.headers || 'SYSTEM';
    try {
        const result = await fetchAnsibleTags(req.body.sys, req.body.tcrno, req.body.curtime, req.body.action, req.body.srctype, req.body.env, sysid);
        if (result.error) {
            console.log("---Error fetching TAGS STATUS:400---", result.error);
            res.status(400).send(result.error);
        } else {
            console.log("---FETCHED TAGS STATUS:200---", result);
            res.status(200).send(result);
        }
    } catch (error) {
        console.log(`error: ${error}`);
        res.status(500).send(error);
    }
}


exports.executeAnsibleTagsPostCheckout = async () => {

}
