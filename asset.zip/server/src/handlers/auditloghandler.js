const { getlogs } = require('../service/auditService');

exports.fetchAuditLogs = async( req , res) =>{
    console.log('----req----', req.body);
    try{
        const fetchLog = await getlogs(req);
        console.log('----fetchresponse---', fetchLog);
        if(fetchLog.error){
            res.status(400).send(fetchLog);
        }else{
            res.status(200).send(fetchLog);
        }
    }catch(error){
        console.log(`error: ${error}`);
        res.status(500).send(error);
    }
}


 
