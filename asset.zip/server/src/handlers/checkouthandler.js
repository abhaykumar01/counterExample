const {  checkout, fetchExecutionId, updateExecutionStatus, updateExecutionStatusDetail}  = require('../util');

const {publishResponse} = require('../graphql/publish');
const { 
    CODE_CHECKOUT_COMPLETED, 
    CODE_CHECKOUT_FAILED,
	EXECUTION_FAILED,
TCR_PROCESSING_FREEZED,
TCR_PROCESSING_RETRYABLE} = require('../constant/executionstate');
const { CODE_CHECKOUT_COMPLETED_MSG} = require('../constant/executionmessage');

exports.checkoutrepository = async(req, res) => {
    console.log('---checkoutrepository request parameters -----', req.body);
    const {repo, tcrno, env, action,  curtime, records, app} = req.body;
    const {sysid} = req.headers || 'SYSTEM';
    console.log('----Going to call fetchExecutionId from checkoutRepository in checkoutHandler---');
    const rec = await fetchExecutionId(tcrno, env, sysid, action.value, repo.version, repo.repo, app);
	console.log('---rec ----', rec);
    try{
        const result = await checkout(repo,tcrno, env, action.value,  curtime, records,sysid, app);

        console.log('--checkoutrepository-result-----',result);
        if(result && result.error){
            console.log('---Error checking out repository 123---',result.error);
            let errMsg = '';
            if(repo.sys ==='git'){
               errMsg = result.error.stderr;
               console.log('----errMsg ----', errMsg);
            }else {
                errMsg = result.stderr;
                console.log('---Non Git scenario-errMsg ----', errMsg);
            }
            
            let resp = {
                message: '',
                error: [errMsg],
                tcrno
            }
            publishResponse('TCR_PROCESSING','tcrProcessing', resp);
            const status2 = await updateExecutionStatusDetail(rec[0], tcrno, CODE_CHECKOUT_FAILED, sysid, app, env,`Checkout of repository ${repo.repo} corresponding to tcrno: ${tcrno} failed`);
            const status21 = await updateExecutionStatus(rec[0],EXECUTION_FAILED,errMsg, TCR_PROCESSING_RETRYABLE, action.value );
            res.status(400).send(result);
        }else{

            let resp = {
                message: `Checkout of repository ${repo.repo} corresponding to tcrno: ${tcrno} completed`,
                error: [],
                tcrno
            }
            publishResponse('TCR_PROCESSING','tcrProcessing', resp);
            const status3 = await updateExecutionStatusDetail(rec[0], tcrno, CODE_CHECKOUT_COMPLETED, sysid, app, env,CODE_CHECKOUT_COMPLETED_MSG);
            //sending the value as result is coming empty from the checkout method
            res.status(200).send(result);
        }
    }catch(error){
        console.log(`error: ${error}`);
        res.status(500).send(error);
    }
}

