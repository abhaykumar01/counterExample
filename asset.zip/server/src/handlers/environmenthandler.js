const { executeStatement,execute}  = require('../db/db');

//By default this api is going to be called for non prod environment
exports.fetchEnvironmentsSpecificToApplication = async (req, res) => {
    console.log('---request parameters ----',req.params);
    try {
        const query = `select DISTINCT(ENV_NAME) from star_app_envnames where parent_sys_id = :app`
         const environments = await executeStatement(query, req.params.app);
         console.log('----environments -----',environments);
         if(environments.rows.length >0 ){
             const data = environments.rows.map( rec => {
                //  if(rec[0] !== 'Production' || rec[0] !=='Disaster Recovery')
                 return {value: rec[0], label: rec[0]}
             }).filter( rec => rec !==undefined).filter(rec =>  rec.value !== 'Production').filter( rec =>  rec.value !== 'Disaster Recovery');

             console.log('----data-----',data);
             res.status(200).send(data);
         }
         else{
             res.status(200).send([])
         }
    } catch (error) {
        console.error('---Error while retrieving the environment names ----',error);
        res.status(500).send(error);
    }
}

exports.fetchAllApplications =  async (req,res) => {
    console.log('--fetching all applications');
    const apps = await execute('select distinct parent_sys_id, instance FROM STAR_CMDB_CI');
    console.log('--apps ---',apps);
    if(apps){
     const applist = apps.rows.map(item => {
          return {
            value: item[0],
            label: item[1]
          }
      });
     console.log('----applist----',applist);
     res.status(200).send(applist);
   }

    // console.log('---users ----', users);
    // let results = []
    // if(users && users.rows){
    //      users.rows.map( row => {
    //          console.log('---row----',row);
    //          results.push({
    //             value: row[1],
    //             label: row[3]
    //         })
            
    //     });
    //   console.log('---results ----', results);

    //     res.status(200).send(results);
    // }
};

exports.fetchApplicationSpecificToUserName = async (req, res) => {
    console.log('--fetching applications for username : ',req.params.username);
     const user = await executeStatement('select SYS_ADMIN from STAR_USER WHERE sys_id= :username', req.params.username);
     console.log('---user---',user);
  
     try{

       if(user && user.rows){
         const flag = user.rows[0];
         console.log('flag ---',flag);
         if(flag[0] === 'Y'){
           const apps = await execute('select distinct parent_sys_id, instance FROM STAR_CMDB_CI');
           console.log('--apps ---',apps);
           if(apps){
            const applist = apps.rows.map(item => {
                 return {
                   value: item[0],
                   label: item[1]
                 }
             });
            console.log('----applist----',applist);
            res.status(200).send(applist);
          }
         }
         else{
            const result = await executeStatement('select distinct parent_sys_id,  instance FROM STAR_CMDB_CI WHERE PARENT_SYS_ID in (SELECT app_instance_sys_id FROM STAR_USER_ROLE WHERE SYS_ID=  :username)', req.params.username );
           console.log('----result ---',result);
           console.log('----request parameters------',req.params.username);
           try{
               if(result){
                   const apps = result.rows.map(item => {
                       return {
                         value: item[0],
                         label: item[1]
                       }
                    });
                   
                   res.status(200).send(apps);
               }
       
           }catch(error){
               console.error('--Error retrieving the application list for user ----');
               res.status(400).send('Error while retrieving list of applications');
           }
         }
       }

  }catch(error) {
    console.error('Error while fetching user details...',error);
    res.status(400).send('Error while fetching User details');
  } 
}