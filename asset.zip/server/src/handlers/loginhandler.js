const jwt = require('jsonwebtoken');
const { executeStatement}  = require('../db/db');
const validateLoginInput = require('../validators/login');
const keys = require('../config/config');

exports.login = async (req, res) => {
    console.log('---process.env-----',process.env.NODE_ORACLEDB_PASSWORD);
    console.log('---process.env-----',process.env.NODE_ORACLEDB_USER);
    console.log('----in login---', req.body);
    const {errors, isValid} = validateLoginInput(req.body);

    //Check validation
    if (!isValid) {
        return res.status(400).json(errors);
    }

    const data = req.body;
    console.log('---data ---',data);
    const {username, password} = data;
    // Search the database for given username . If user is not found then return response

    const query = `select * from star_user where email = :username`;
    console.log('---query---', query);

    const result = await executeStatement(query, username);
    console.log('---login result ---', result);

    if(result.rows.length > 0){

        console.log('---result rows ----', result.rows);
       
        if(password === result.rows[0][3]){
            let prodaccess = false;
            if (result.rows[0][4] === 'Y' || result.rows[0][5] === 'Y')  {
                prodaccess = true;
            } 
           
            const payload = {
                username: username,
                sys_id: result.rows[0][0],
                role: result.rows[0][4]==='Y'?'sysadmin': 'admin',
                prodaccess: prodaccess  
            }
            
                jwt.sign(payload, keys.secretOrKey,
                    {
                        expiresIn: 31556926 //1 year in seconds
                    },
                    (err, token) => {
                        res.json({
                            success: true,
                            token: "Bearer "+token
                        });
                    });
        }
        else{
            return res.status(404).json("Invalid Credential");
        }
        
        
    }else {
        //error
        return res.status(404).json(`${username} does not exist`);
    }
 
};
