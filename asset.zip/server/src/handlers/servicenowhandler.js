
const {getServiceNowInfo} = require('../service/ServiceNow');

exports.serviceNowTcrProcessing = async (req,res,next) => { 
    console.log('------------------------', req.body);
    const data = req.body;
    const {tcrno, env, action,application} = data;
    const {sysid} = req.headers || 'SYSTEM';
    try{
    const records = await getServiceNowInfo(tcrno, env, action, application, sysid);
    console.log('---records ----',records);
     if(records.error){
                res.status(400).send({...records,tcr:{state:1, number: tcrno}});
            }
            else{
                res.status(200).send(records);
            }
    
          }catch(error) {
            console.log(`error: ${error}`)
            res.status(500).send(error);
        }
    
    }