const {vault} = require('../Vault');
require('dotenv').config();

exports.uploadFile = async (req, res, next) => {
    
    console.log('---req---',req.body);
console.log('----type---', req.vaultType)    
try{
        let upload = req.files.file;
        const fileName = req.files.file.name;
        const type = req.body.vaultType;
        console.log('----uploadFile----',upload);
        console.log('----fileName----',fileName);
        console.log('----type----', type);
        //Here we need to encryp the files
        if(type === "encrypt"){
            upload.mv(
                `${process.env.NODE_UPLOAD_FOLDER}/${fileName}`,
                function (err) {
                    if (err) {
                        return res.status(500).send(err);
                    }
                    const ansiblevault = vault(`sh ${process.env.NODE_APP_HOME}/encrypt.sh ${process.env.NODE_UPLOAD_FOLDER}/${fileName}`);
                    res.json({
                        file: `public/${req.files.file.name}`,
                    })
                },
            )
        }else{
            upload.mv(
                `${process.env.NODE_UPLOAD_FOLDER}/${fileName}`,
                function (err) {
                    if (err) {
                        return res.status(500).send(err);
                    }
                    const ansiblevault = vault(`sh ${process.env.NODE_APP_HOME}/decrypt.sh ${process.env.NODE_UPLOAD_FOLDER}/${fileName}`);
                    res.json({
                        file: `public/${req.files.file.name}`,
                    })
                },
            )
        }
       
    }catch(error){
        console.error('Error while uploading the file');
    }
 
	//const ansiblevault = await vault(`sh {process.env.NODE_APP_HOME}encrypt.sh ${__dirname}/public/${fileName}`);  
}
