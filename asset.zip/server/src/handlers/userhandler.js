const {addNewUser,resetPassword} = require('../service/UserService');

exports.createNewUser = async(req, res) => {
    console.log('---request parameters in users-----', req.body);
    const {user} = req.body;

    try{
        const newUser = await addNewUser(user);

        if(newUser.error){
            res.status(400).send(newUser);
        }else{
            res.status(200).send(newUser);
        }
    }catch(error){
        console.log(`error: ${error}`);
        res.status(500).send(error);
    }
}

exports.changeUserPassword = async(req, res) => {
    console.log('---request parameters in users-----', req.body);
    const {user} = req.body;

    try{
        const newUser = await resetPassword(user);

        if(newUser.error){
            res.status(400).send(newUser);
        }else{
            res.status(200).send(newUser);
        }
    }catch(error){
        console.log(`error: ${error}`);
        res.status(500).send(error);
    }
}