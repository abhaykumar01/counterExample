const express = require('express');
require('dotenv').config();
const cors = require('cors');

const {ApolloServer} = require('apollo-server');
const {makeExecutableSchema} = require('graphql-tools')
const schema = require('./graphql/schema');
const resolvers= require('./graphql/resolvers');
const fileUpload = require('express-fileupload');
const passport = require('passport');

const {login} = require('./handlers/loginhandler');
const {createNewUser, changeUserPassword} = require('./handlers/userhandler');
const {checkoutrepository} = require('./handlers/checkouthandler');
const {fetchEnvironmentsSpecificToApplication,
     fetchAllApplications, fetchApplicationSpecificToUserName} = require('./handlers/environmenthandler');
const {executeAnsibleTags, fetchAnsibleTags} = require('./handlers/ansiblehandler');
const {uploadFile} = require('./handlers/uploadhandler');
const {serviceNowTcrProcessing} = require('./handlers/servicenowhandler');
const {fetchAuditLogs} = require('./handlers/auditloghandler');

const app = express();

app.use(express.json());
app.use(express.urlencoded());
app.use(cors());
app.use(fileUpload());
app.use('/public', express.static(__dirname+ '/public'))

app.use(passport.initialize());
app.use(passport.session());

//Login route
app.post("/login",login);

//Route to onboard new user
app.post('/users',createNewUser); 

//Route to change user password
app.post('/users/changepassword',changeUserPassword ) 

//Route to checkoutrepository 
app.post('/svncheckout',checkoutrepository );

// app.get('/gitclone',cloneGitRepository );

app.get('/environments/:app',fetchEnvironmentsSpecificToApplication );


app.post('/executeAnsibletags',executeAnsibleTags );

app.post('/fetchAnsibleTags', fetchAnsibleTags);

app.post('/fetchAuditLogs', fetchAuditLogs);


app.get('/servicenow/:tcrno', async (req, res) => {
    console.log('----request parameters----',req.params.tcrno );

})

app.get('/applications', fetchAllApplications);

app.get('/applications/:username',fetchApplicationSpecificToUserName );

app.post('/param', serviceNowTcrProcessing );

app.post('/upload', uploadFile );

app.get('/crashapp', (req, res) => {
    console.log('----used for testing crashing of application ----');
    process.exit(1);
})


const executableSchema = makeExecutableSchema({
    typeDefs: schema,
    resolvers
})


const server = new ApolloServer({
    schema: executableSchema,
    playground: true,
})

server.listen().then(({url, subscriptionsUrl}) => {
    console.log(`Apollo Server started at ${url}`);
    console.log(`Subscription Server started at ${subscriptionsUrl}`);
})
app.listen(5000, () => {
    console.log('App listening on port 5000!');
})
