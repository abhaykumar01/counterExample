const Ansible = require('../ansible/ansible');
const logger = require('../Logger');
const execFileSync = require('child_process').execFileSync;
const execEmail = require('child_process').execSync;
const { sendEmail, verifyServersAssociatedWithEnvironment, updateExecutionStatus, 
  updateExecutionStatusDetail,
  updateExecutionStatusWithTags } = require("../util");
const { ANSIBLE_TAGS_EXECUTION_INITIATED,
  ANSIBLE_TAGS_EXECUTION_COMPLETED,
  EXECUTION_SUCCESSFUL,
  HEALTH_CHECK_FAILED,
  HEALTH_CHECK_INITIATED,
  HEALTH_CHECK_COMPLETED,
  TCR_PROCESSING_FREEZED,
  EXECUTION_FAILED,
ANSIBLE_TAGS_EXECUTION_FAILED, TCR_PROCESSING_RETRYABLE } = require('../constant/executionstate');
const { publishResponse } = require('../graphql/publish');
const {HEALTH_CHECK_INITIATED_MSG,
  HEALTH_CHECK_COMPLETED_MSG,
  EXEUCTION_ANSIBLE_TAGS_FAIL_MSG} = require('../constant/executionmessage');


const executePlaybook = async (srcsys, svnrepo, tcrno, action, env, curtime, ansible_tags, email) => {
  //path is the location where the playbook has been checked out
  //
  //
// ${tcrno} ${records.mcr.number} ${records.mcr.state} ${records.tcr.state} ${records.repository.repo_path} ${records.repository.repo_revision} /export/home/rmadmin/deploy_ansible/logs/${tcrno}_${curtime}.log ${records.assignee_info.email}`);
//Need to call the service now to fetch the data in case of Prod  
//let records = {
//      mcrstate: 'Authorized',
//      tcrstate:'-2',
//      repo_path: '',
//      repo_revision: '',
//      email: ''
//  }
  //const log = logger(tcrno, curtime);
  //console.log("--- AnsibleService.js - Parameters received for playbook ---", srcsys, svnrepo, tcrno, action, env, curtime, ansible_tags)

  const log = logger(tcrno,curtime);
    log.log({
      level: "info",
      message: `Executing tags:${ansible_tags} for ${tcrno}.`
    });


  const response = {
    message: `Executing tags:${ansible_tags} for ${tcrno}`,
    error: [],
    tcrno
  };

  publishResponse('TCR_PROCESSING', 'tcrProcessing', response);
  try {
    let srcLocation = "SVNcheckout";
    if (srcsys === "GIT" || srcsys === 'git') { srcLocation = "GITclone" }

    let play = "site"
    if (action === "Rollback") { play = "rollback" }

    const vaultFileLocation = `../..`;
    let playbookfile = `${process.env.NODE_STAR_CHECKOUT_DIR}/${srcLocation}/${tcrno}_${curtime}/${play}`;
    let inventoryfile = `${process.env.NODE_STAR_CHECKOUT_DIR}/${srcLocation}/${tcrno}_${curtime}/inventories/${env}/hosts`;
    console.log('-----playboofile ----', playbookfile);
    console.log('------inventory file ---------',inventoryfile);
    let playbook = new Ansible.Playbook()
      .playbook(`${playbookfile}`)
      .inventory(`${inventoryfile}`)
      .vaultPassFile(`${process.env.NODE_STAR_CHECKOUT_DIR}/${srcLocation}/${tcrno}_${curtime}/vaultkeyfile`)
      .verbose('vv')
       .tags(`${ansible_tags}`);

    playbook.on('stdout', (data) => {
      console.log('--stdout ---',data.toString());
    })

    
    playbook.on('stderr', (data) => {
      console.log('--stderr ---',data.toString());
    })
    const result = await playbook.exec();

    console.log('--ansible execution result ---', result);
    log.log("info", `${result.output}`);
    //TO FIX THIS ISSUE
    //NODE_STAR_LOGS_DIR
    console.log('---Going to SEND EMAIL ----2-');
    const emailstatus = execEmail(`${process.env.NODE_APP_HOME}/sendmail.sh Success ${tcrno} ${env} ${process.env.NODE_STAR_LOGS_DIR}/${tcrno}_${curtime}.log ${email}`);
    let res1 = {
      message: `Ansible Script executed successfully : ${result.output}`,
      error: [],
      tcrno: tcrno
    };

    publishResponse('TCR_PROCESSING', 'tcrProcessing', res1);

    return result;
  } catch (error) {
    console.error('Error while executing ansible playbook--', error);
    log.log("error", `${error}`);
    let res1 = {
      message: '',
      error: [`Ansible Error: ${error}`],
      tcrno
    };

    publishResponse('TCR_PROCESSING', 'tcrProcessing', res1);

    // TODO : Fixing the mcr and other value  which is not available in case of non prod
    console.log('---Going to SEND EMAIL -----1');
    const emailstatus = execEmail(`${process.env.NODE_APP_HOME}/sendmail.sh Failure ${tcrno} ${env} ${process.env.NODE_STAR_LOGS_DIR}/${tcrno}_${curtime}.err.log ${email}`);
   

    return { error: `Playbook executed with error: ${error} ` };
  }
}

const executeAnsibleTags = async (ansible_tags) => {

  console.log('...ansible tags ....', ansible_tags);

}

const fetchAnsibleTags = async (app, tcrno, curtime, action,sys,env,sysid) => {
  console.log('---fetchAnsibleTags ----',app, sys, tcrno, curtime, action, env);
  let play = "site.yml";
  if (action === "Rollback") { play = "rollback.yml" }

  let pkgPath = `${process.env.NODE_STAR_CHECKOUT_DIR}/SVNcheckout/${tcrno}_${curtime}/${play}`;
  if (sys === 'GIT' || sys === 'git') { 
    pkgPath = `${process.env.NODE_STAR_CHECKOUT_DIR}/GITclone/${tcrno}_${curtime}/${play}` 
  }

  try {
    console.log('---pkgPath ----', pkgPath);
    const ansibleTags = execFileSync(`${process.env.NODE_APP_HOME}/fetchAnsibleTags.sh`, [`${pkgPath}`]).toString();

    //Going to execute ansible script to pull out tags list
    var tags_responses = {
      tags: ansibleTags.split(','),
      error: [],
      tcrno,
      svnrepo: tcrno,
      svnrevision: curtime
    }
    console.log('----Going to publish the tag list info-----', tags_responses);
    publishResponse('TAGS_LIST_AVAILABLE', 'tagsProcessing', tags_responses);
    let sourcerepotype = 'SVNcheckout';
    if(sys === 'GIT' || sys ==='git'){
      sourcerepotype = 'GITclone'
    }
    // const isVerified = await verifyServersAssociatedWithEnvironment(process.env.NODE_STAR_CHECKOUT_DIR + `/${sourcerepotype}/${tcrno}_${curtime}`, env, app, tcrno, sysid);
    // console.log('-----isVerified fetchAnsible Tags ---', isVerified);
    return ansibleTags.split(',')
  }
  catch (error) {
    console.log("--- Error message FetchTags ---", error.message);
    let res1 = {
      message: '',
      error: [`Error Fetching Ansible Tags: ${error}`],
      tcrno
    };

    publishResponse('TCR_PROCESSING', 'tcrProcessing', res1);

    return { 'error': error.message };
  }

}


const healthCheck = async (execution_id, srcsys, svnrepo, tcrno, action, env, curtime, ansible_tags, app, sysid, email) => {
  console.log('----healthcheck ----',execution_id, ' : ', srcsys, ' : ',svnrepo, ' : ',env);
  try {

    let srcLocation = "SVNcheckout";
    if (srcsys === "GIT" || srcsys === 'git') { srcLocation = "GITclone" }
    if (env === 'Production' || env ==='PROD') {
      updateExecutionStatusDetail(execution_id, tcrno, HEALTH_CHECK_INITIATED, sysid, app, env, HEALTH_CHECK_INITIATED_MSG);
    }
    publishResponse('TCR_PROCESSING', 'tcrProcessing', {
      message: `${tcrno}: ${HEALTH_CHECK_INITIATED_MSG}`,
      error: [],
      tcrno
    })
    const vaultFileLocation = `../..`;
    let playbook = new Ansible.AdHoc()
      .hosts('all')
      .inventory(`${process.env.NODE_STAR_CHECKOUT_DIR}/${srcLocation}/${tcrno}_${curtime}/inventories/${env}/hosts`)
      .vaultPassFile(`${process.env.NODE_STAR_CHECKOUT_DIR}/${srcLocation}/${tcrno}_${curtime}/vaultkeyfile`)
      .module('ping');
    let result = {};
    try {
      playbook.on('stdout', (data) => {
        console.log('--stdout healthcheck---',data.toString());
      })
  
      
      playbook.on('stderr', (data) => {
        console.log('--stderr healthcheck---',data.toString());
      })
      result = await playbook.exec();
      const status = await updateExecutionStatusDetail(execution_id,tcrno, HEALTH_CHECK_COMPLETED, sysid, app, env, HEALTH_CHECK_COMPLETED_MSG);
      console.log('---result after executing Playbook 2121');
      publishResponse('TCR_PROCESSING', 'tcrProcessing', {
        message: `${tcrno}: ${HEALTH_CHECK_COMPLETED_MSG}`,
        error: [],
        tcrno
      });

      // return result;
    } catch (error) {
      console.log('---error during healthcheck ----',error);
      log.log("error", `${error}`);
      // const regex = /([a-zA-Z]*[0-9]+\s\|\sSUCCESS)|([a-zA-Z]*[0-9]+\s\|\sUNREACHABLE!)/;
      const regex = /([a-zA-Z]*[0-9]+\s\|\s(SUCCESS|UNREACHABLE!))/g;
      let  match = findFilteredMessage(error, regex);
      if(match === null){
          match = error.toString().substring(0,200) + '...';
          console.log('---regex match was null ----',match);
      }
      await updateExecutionStatusDetail( execution_id ,tcrno, HEALTH_CHECK_FAILED, sysid, app, env, match);
      await updateExecutionStatus(execution_id,  EXECUTION_FAILED, match ,TCR_PROCESSING_RETRYABLE, action);
      const healthcheck = {
        message: match ,
        error: [],
        tcrno
      };
      console.log('---healthcheck message -----', healthcheck);
       publishResponse('HEALTH_CHECK_PROCESSING', 'healthCheckProcessing', healthcheck);
      
       publishResponse('TCR_PROCESSING', 'tcrProcessing', {
         message: '',
         error: [`${tcrno}: ${match}`],
         tcrno
       });

      console.error('--healthCheck () -matched regex--\n', match);

      return {error: match};
    }

    console.log('--healthCheck () - Ansible health check result ---\n', result);

    const status1 = await updateExecutionStatusDetail(execution_id,tcrno, ANSIBLE_TAGS_EXECUTION_INITIATED, sysid, app, env, `Execution of ansible tags ${ansible_tags} Initiated`);
    const executionResultOfPlaybook = await executePlaybook(srcsys, svnrepo, tcrno, action, env, curtime, ansible_tags, email);
    console.log('----executionResultOfPlaybook ---', executionResultOfPlaybook);
    const status2 = await updateExecutionStatusDetail(execution_id,tcrno, ANSIBLE_TAGS_EXECUTION_COMPLETED, sysid, app, env, executionResultOfPlaybook.toString());
   if(env ==='Production'){
    console.log('----Going (production) to update the tags -------', ansible_tags);
    await updateExecutionStatusWithTags(execution_id,  EXECUTION_SUCCESSFUL, 'SUCCESSFUL',TCR_PROCESSING_FREEZED ,action,ansible_tags);
    
    // await updateExecutionStatusTags(execution_id,ansible_tags);
    console.log('----Updated (production) to update the tags -------', ansible_tags);
   }else{
    console.log('----Going (non production) to update the tags -------', ansible_tags);
    await updateExecutionStatusWithTags(execution_id,  EXECUTION_SUCCESSFUL, 'SUCCESSFUL',TCR_PROCESSING_RETRYABLE, action, ansible_tags );
   
    // await updateExecutionStatusTags(execution_id,ansible_tags);
    console.log('----Updated (non-production) to update the tags -------', ansible_tags);
   }
    console.log('---status2----', status2);
    return result;
  } catch (error) {
    console.error('----Error Execution ansible tags ----', error);
    log.log("error", `${error}`);
    const status2 = await updateExecutionStatusDetail(execution_id,tcrno, ANSIBLE_TAGS_EXECUTION_FAILED, sysid, app, env, executionResultOfPlaybook.toString());
    await updateExecutionStatusWithTags(execution_id,  EXECUTION_FAILED, EXEUCTION_ANSIBLE_TAGS_FAIL_MSG,TCR_PROCESSING_RETRYABLE, action, ansible_tags );
    // await updateExecutionStatusTags(execution_id,ansible_tags);
    return {error: error};
  }
}

const findFilteredMessage = (message, regex) => {
  let filteredMessage = message.toString().match(regex);
  return filteredMessage;
}
module.exports = { executePlaybook, executeAnsibleTags, fetchAnsibleTags, healthCheck };

