const { executeStatementWithObjectParams, execute}  = require('../db/db');

 const fetchServerInfo = async (env, app) => {
     console.log('---fetchServerInfo -----', env,app);
     let tmpEnv = env;
     if (env ==='PROD' || env === 'Production') {
         tmpEnv = 'Production';
     }
    let query = `select * from star_cmdb_ci_view where env_category = :env AND parent = (select distinct instance from STAR_CMDB_CI WHERE parent_sys_id= :parent )`;
    if(env === 'Production'){
        try {
            query = `select * from star_cmdb_ci_view where (env_category = :env1 OR env_category =:env2) AND parent = (select distinct instance from STAR_CMDB_CI WHERE parent_sys_id= :parent )`;
            const resultProd = await executeStatementWithObjectParams(query, {
                env1: 'Production',
                env2: 'Disaster Recovery',
                parent: app
            });
        
            console.log('--fetchServerInfo-server Prod or DR names : ---',resultProd);
            return resultProd;      
        } catch (error) {
            console.error('---Error while fetching the server information ---', error);
            throw new Error(`Error Fetching the Server Information ${error}`)
        }
       
    }
    
    console.log('---query---', query);
    try {
        const result = await executeStatementWithObjectParams(query, {
            env: tmpEnv,
            parent: app
        });
    
        console.log('--fetchServerInfo-server names : ---',result);
        return result;    
    } catch (error) {
        console.error('---Error while fetching the server information ---', error);
        throw new Error(`Error Fetching the Server Information ${error}`);
    }
    
}

module.exports = {fetchServerInfo}