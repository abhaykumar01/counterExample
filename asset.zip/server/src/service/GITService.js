const simpleGit = require('simple-git/promise');
const { srcUserName, srcPassword } = require('../config/config');
const rimraf = require('rimraf');
const sGit = require('simple-git');
const exec = require('shelljs.exec');

const checkoutWithSpecificRevision = async (localRepoPath, revision) => {
  try {
    console.log('--Going to checkout repository version ---');
    return new Promise((resolve, reject) => {
      sGit().cwd(localRepoPath)
      .checkout(revision,
        (err, data) => {
          if (!err) {
            console.log("----CHECKOUT SPECIFIC VERSION----");
            return { message: 'Checked out revision succesfully' }
          }
          else {
            console.log("--- ERROR :: GIT CHECKOUT TO SPECIFIC REVISION FAILED---", err);
            //	    throw new Error(err);				
            return { error: `Error Checking out specific revision ${revision}` };
          }

        });
    })

  } catch (error) {
    console.error(`---Error while checking out revision ${revision}`, error);
    return error;
  }

}

const checkoutWithSpecificRevisionUsingCommandLine = async (localRepoPath, revision) => {
  try {
    console.log('--Going to checkout repository version ---', revision);
    const checkoutResult = exec(`cd ${localRepoPath} && git checkout ${revision}`);
    console.log('----checkoutWithSpecificRevisionUsingCommandLine result --', checkoutResult);

    return checkoutResult;
  } catch (error) {
    console.error(`---Error while checking out revision ${revision}`, error);
    return error;
  }
}

const cloneGIT = async (repo, tcrno, env, action, curtime, records, sysid, app_instance_id,execution_id) => {

  console.log('--ENTER GIT CLONE---', repo, tcrno, action, curtime, env);

  const localRepoPath = `${process.env.NODE_STAR_CHECKOUT_DIR}/GITclone/${tcrno}_${curtime}`;
  console.log('---localRepoPath ---', localRepoPath);
  let remoteRepo = `https://${srcUserName}:${srcPassword}@stash.dts.fm.rbsgrp.net${repo.repo}`;
  console.log('--remoteRepo ---', remoteRepo);
  // Clone GIT  repository branch
  // let tcr = '';
  rimraf.sync(localRepoPath);
  console.log(`${localRepoPath} directory deleted before cloning the repo`);

  if (env !== 'Production' || env !== 'PROD') {
    let status = {};
    try {
      status = await simpleGit()
        .clone(remoteRepo,
          localRepoPath,
          async (err, data) => {
            if (!err) {
              console.log('---Repository cloned successfully ---', data);
            }
            else {
              console.log("---ERROR :: GIT  CLONE FAILED non production---", err);
            }
          })
    } catch (error) {
      console.log('----Error while cloning the repository : ', error);
      let checkoutrepo = `https://stash.dts.fm.rbsgrp.net${repo.repo}`;
      return { error:{ error, stderr: `Error Checking out repository ${checkoutrepo}` } }
    }
    console.log('---status after clone operation ---', status);
    try {
      const st = await checkoutWithSpecificRevisionUsingCommandLine(localRepoPath, repo.version);

      if (st.error) {
        console.error('---Error while checking out revision ----', st);
        return { error: st }
      } else {
        console.log('----result after checkoutWithSpecificRevisionUsingCommandLine ---',st);
        return st;
      }
    } catch (error) {
      console.error('---Error during checkout ---', error);
      return { error: error };
    }
  }

  const cloneStatus = await simpleGit()
    .clone(remoteRepo,
      localRepoPath,
      ["-b", `${tcrno}`],
      (err, data) => {
        if (!err) {
          console.log('---Cloning of Git repository was sucessfully---',data);
        }
        else {
          console.error("--- Error cloning Git Repository -----", err);
          return { error: err };
        }
      })
    .cwd(localRepoPath)
    .checkout(`${repo.version}`,
      (err, data) => {
        if (!err) {
          console.log("----CHECKOUT SPECIFIC VERSION----");
        }
        else {
          console.log("--- ERROR :: GIT CHECKOUT TO SPECIFIC REVISION FAILED---");
          return { error: `Error Checking out specific revision ${repo.version}` };
        }

      });
  return cloneStatus;
}


module.exports = { cloneGIT };
