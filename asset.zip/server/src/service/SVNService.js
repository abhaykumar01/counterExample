const svnUltimate = require('node-svn-ultimate');
const { srcUserName, srcPassword } = require('../config/config');
const {publishResponse} = require('../graphql/publish');
const logger = require('../Logger');
const exec = require('shelljs.exec');

const svncheckout = async (repo, tcrno,  curtime, records) => {

  console.log("---SVNService.js checkout ()", curtime, '------',tcrno );

  let res = `https://svn.dts.fm.rbsgrp.net${repo.repo}@${repo.version}`;

  console.log('---------PATH-------', res);
  let resp =  {
    message: `Initiating checkout of ${repo.repo}@${repo.version} `,
    error: [],
    tcrno
  }
  
  publishResponse("TCR_PROCESSING",'tcrProcessing', resp);

  console.log('--Going to checkout the repository ----');

  const log = logger(tcrno,curtime);
  log.log({
    level: "info",
    message: `Going to checkout the repository ${res} .`
  });

  const checkoutResult = exec(`svn checkout ${res} --username ${srcUserName} --password ${srcPassword} ${process.env.NODE_STAR_CHECKOUT_DIR}/SVNcheckout/${tcrno}_${curtime}`);
  console.log('----checkoutResult ----',checkoutResult);


  // const status = await svnUltimate.commands.checkout(res,
  //   `${process.env.NODE_STAR_CHECKOUT_DIR}/SVNcheckout/${tcrno}_${curtime}`, {
  //     username: `${srcUserName}`,
  //     password: `${srcPassword}`,
  //     trustServerCert: true
  //   }, (err) => {
  //     console.log('---err---', err);
  //     if (!err) {
  //       console.log('---SVNService.js SVN respo checkout Success', `${process.env.NODE_STAR_CHECKOUT_DIR}/SVNcheckout/${tcrno}_${curtime}`);
  //      let resp =  {
  //       message: `SVN Checkout successfull`,
  //       error: [],
  //       tcrno
  //     }
  //     publishResponse("TCR_PROCESSING",'tcrProcessing', resp);
    
  //     } else {
  //       const errorMsg = getCheckoutErrorMessage(err, repo);
  //       let resp = {
  //         message: '',
  //         error: [errorMsg],
  //         tcrno
  //       }
  //       publishResponse("TCR_PROCESSING",'tcrProcessing', resp);
  //       console.error('---Error While checking out repository :',errorMsg);
  //       return {error: errorMsg};
  //     }
  //   })

  return checkoutResult;
}
const getCheckoutErrorMessage = (error, repo) => {
  console.log('---getCheckoutErrorMessage ---', error.toString());
  if(error.toString().includes('E170000')) {
    return `svn: E170000: URL ${repo.repo} doesn't exist`;
  }else if(error.toString().includes('E160006')){
    return `svn: E160006: No such revision ${repo.version}`
  }else {
    return `Failed to checkout ${repo.repo}@${repo.version}`
  }
}
module.exports = { svncheckout };
