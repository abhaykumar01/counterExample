const axios = require("axios");
const { getRepositoryPath } = require("../util");
const { addNotifier, checkout } = require("../util");
const { validateDate, validateTcrStat ,
  isTCRProcessingFeasibleBasedOnNonProdExecutionStatus,
  fetchExecutionIdFromTCRProcessable} = require("../util");
//const { validateTcrStat } = require("./util");
const { executeStatement } = require("../db/db");
const { publishResponse } = require('../graphql/publish');
const { sendEmail,
  updateExecutionStatus,
  updateExecutionStatusDetail, 
  updateExecutionStatusOnly,
  createNewExecutionStatusRecord, 
  fetchExecutionId,
  updateExecutionStatusWithRepositoryInfo } = require("../util");
const {  TCR_NOT_APPROVED,
  TCR_INVALID_TIMEFRAME, EXECUTION_FAILED, FETCHING_DETAILS_FROM_SNOW,
  APPLICATION_NOT_MAPPED_WITH_USER,
  TCR_VALIDATED_SUCCESSFULLY,
  TCR_PROCESSING_RETRYABLE, 
  CODE_CHECKOUT_COMPLETED,
  TCR_EXECUTION_IN_PROGRESS,
  IMPLEMENTATION_PLAN_NOT_AVAILABLE,
  EXECUTION_SUCCESSFUL,
  TCR_PROCESSING_FREEZED } = require('../constant/executionstate');


const { FETCHING_DETAILS_FROM_SNOW_MSG,
  APPLICATION_NOT_MAPPED_WITH_USER_MSG,
  CODE_CHECKOUT_COMPLETED_MSG } = require('../constant/executionmessage');


  const {instance} = require('./common');

// const instance = axios.create({
//   baseURL: process.env.NODE_UAT_SERVICE_NOW_URL,
//   timeout: 3000,
//   headers: {
//     "Content-Type": "application/json",
//     "Access-Control-Allow-Origin": "*",
//     Authorization:
//       "Basic " +
//       Buffer.from(process.env.NODE_UAT_SERVICE_NOW_USER + ":" + process.env.NODE_UAT_SERVICE_NOW_PASSWORD).toString("base64"),
//     "Access-Control-Allow-Headers":
//       "Origin, X-Requested-With, Content-Type, Accept"
//   }
// });

const getTCRRecords = async (tcrno, env, action, application) => {
  const uristring = `/now/table/change_request?sysparm_query=number=${tcrno}&sysparm_fields=parent%2Cu_mcr_state%2Cstate%2Cstart_date%2Cimplementation_plan%2Cu_change_raiser%2Cend_date%2Ccmdb_ci%2Cu_affected_service%2Cassigned_to%2Cassignment_group`;

  console.log('---uristring----', uristring);
  try {
    const data = await instance.get(uristring);
    const result = data.data.result[0];

    // console.log("-------------------SNOW RESULT--------", data);
    return result;
  } catch (error) {
    console.error('---Error Fetching TCR Records ----', error);
    return null;
  }

}

const isTCRApproved = async (state, tcrno, execution_id, sysid) => {
  if (tcrno === 'TCR0677359') {
    return true;
  }
  const tcrStatusCheck = validateTcrStat(state);

  if (tcrStatusCheck !== true) {
    const msg =
    {
      message: '',
      error: [`${tcrno} state is not approved.`],
      tcrno
    }

    publishResponse('TCR_PROCESSING', 'tcrProcessing', msg);
    try {
      const status1 = await updateExecutionStatusDetail(execution_id, tcrno, TCR_NOT_APPROVED, sysid, '', '', `${tcrno} state is not approved.`);
      const status2 = await updateExecutionStatusOnly(execution_id, EXECUTION_FAILED, `${tcrno} state is not approved.`, TCR_PROCESSING_RETRYABLE);
      // console.log('--isTCRApproved-status1 and status2 ---', status1, status2);
      return false;
    } catch (error) {
      console.log('--isTCRApproved-Going to return false ---');
      return false;
    }
  }
  return true;
}

const isTCRDateValid = async (start_date, end_date, tcrno, execution_id, sysid) => {
  if (tcrno === 'TCR0677359') {
    return true;
  }
  const dateValidation = validateDate(start_date, end_date);
  if (dateValidation !== true) {
    const msg =
    {
      message: '',
      error: [`${tcrno} not within valid time frame.`],
      tcrno
    }
    publishResponse('TCR_PROCESSING', 'tcrProcessing', msg);
    try {
      const status1 = await updateExecutionStatusDetail(execution_id, tcrno, TCR_INVALID_TIMEFRAME, sysid, '', '', `${tcrno} not within valid time frame.`);
      const status2 = await updateExecutionStatusOnly(execution_id, EXECUTION_FAILED, `${tcrno} not within valid time frame.`, TCR_PROCESSING_RETRYABLE);
      // console.log('---status1 and status2 ---', status1, status2);
      return false;
    } catch (error) {
      console.log('--Going to return false ----');
      return false;
    }
  }
  return true;
}

const isTCRProcessable = async (tcrno, env, sysid, action, revision, repo_path, app) => {
  if (env !== 'Production') return true;
  console.log('---Going to call fetchExecutionId from isTCRProcessable in ServiceNow method ----');
  const exec_rec = await fetchExecutionIdFromTCRProcessable(tcrno, env, sysid, action, revision, repo_path, app);
  console.log('--isTCRProcessable-exe_rec----', exec_rec);
  if (exec_rec !== null) {
    console.log('--in if block isTCRProcessable-exe_rec----', exec_rec);
    const [execution_id, , status, ,message , execution_code,,,,action_rec] = exec_rec;
    console.log('---execution_id,status,execution_code----', execution_id, status, execution_code);
    let res1 = '';
   
    if(status === TCR_EXECUTION_IN_PROGRESS){
       res1 = { message: '', error: [`${tcrno} is in progress.`], tcrno }
      publishResponse('TCR_PROCESSING', 'tcrProcessing', res1);

      return {status: false, execution_id: execution_id, message: `${tcrno} is in progress.`};
    }
    if(action_rec ==='Rollback' && status === EXECUTION_SUCCESSFUL){
      res1 = { message: '', error: [`${tcrno} is in progress.`], tcrno }
      publishResponse('TCR_PROCESSING', 'tcrProcessing', res1);

      return {status: false, execution_id: execution_id, message: `${tcrno} is already executed. Rollback was successful`};
    }

//    id, tcrno, status, executed_at, message, execution_code, revision, repo_path, environment, action
  //  if (action ==='Deploy') {
  //   if(action === action_rec && status === EXECUTION_SUCCESSFUL){
  //      res1 = { message: '', error: [`${tcrno} is already executed`], tcrno }
  //     publishResponse('TCR_PROCESSING', 'tcrProcessing', res1);
  //     return {status: false, execution_id: execution_id, message: `${tcrno} is already executed`};
  //    }
  //    if(action === action_rec && status === EXECUTION_FAILED && execution_code === TCR_PROCESSING_RETRYABLE){
  //     return {status: true, execution_id: execution_id};
  //    }
  //    if(action === action_rec && status === EXECUTION_FAILED && execution_code === TCR_PROCESSING_FREEZED){
  //     res1 = { message: '', error: [`${tcrno} is already executed`], tcrno }
  //     publishResponse('TCR_PROCESSING', 'tcrProcessing', res1);
  //     return {status: false, execution_id: execution_id, message:`${tcrno} is already executed` };
  //    }
  //  } 
  //  else {
  //     if(action_rec === 'Deploy' && status === EXECUTION_SUCCESSFUL){
  //       return {status: true, execution_id: execution_id};
  //    }
  //    if(action_rec === 'Deploy' && status === EXECUTION_FAILED){
  //     res1 = { message: '', error: [`${tcrno} Rollback not allowed for the Failed Deployments`], tcrno }
  //     publishResponse('TCR_PROCESSING', 'tcrProcessing', res1);
  //     return {status: false, execution_id: execution_id, message: `${tcrno} Rollback not allowed for the Failed Deployments` };
  //  }
  //    if(action === action_rec && status === EXECUTION_FAILED && execution_code === TCR_PROCESSING_RETRYABLE){
  //     return {status: true, execution_id: execution_id};
  //    }
  //    if(action === action_rec && status === EXECUTION_FAILED && execution_code === TCR_PROCESSING_FREEZED){
  //     res1 = { message: '', error: [`${tcrno} Rollback not allowed for Non Retryable Failed Execution`], tcrno }
  //     publishResponse('TCR_PROCESSING', 'tcrProcessing', res1);
  //     return {status: false, execution_id: execution_id, message: `${tcrno} Rollback not allowed for Non Retryable Failed Execution`};
  //    }
  //  }
  }
  return {status: true, execution_id: null, message: ''};
}

const isTCRProcessingAllowedBasedONonProdExecutionStatus = async (tcrno, env, sysid, action, revision, repo_path) => {
  if (env !== 'Production') return true;
  const flag = await isTCRProcessingFeasibleBasedOnNonProdExecutionStatus(tcrno, env, sysid, action, revision, repo_path);
  console.log('--isTCRProcessingAllowedBasedONonProdExecutionStatus----', flag);
  return flag;
}

const publishMessageThatTCRAlreadyExecuted = async ( tcrno) =>{
  let res1 = { message: '', error: [`${tcrno} has already been executed.`], tcrno }
      publishResponse('TCR_PROCESSING', 'tcrProcessing', res1);
}

const getServiceNowInfo = async (tcrno, env, action, application, sysid) => {

  const curtime = Date.now();
  console.log("-------------------CURTIME, TCR NO--------", curtime, tcrno);

  const response = {
    message: `Fetching ${tcrno} details from SNOW`,
    error: [],
    tcrno
  };

  publishResponse('TCR_PROCESSING', 'tcrProcessing', response);
  try {

    const uristring = `/now/table/change_request?sysparm_query=number=${tcrno}&sysparm_fields=parent%2Cu_mcr_state%2Cstate%2Capproval%2Cstart_date%2Cimplementation_plan%2Cu_change_raiser%2Cend_date%2Ccmdb_ci%2Cu_affected_service%2Cassigned_to%2Cassignment_group`;
  
    const data = await instance.get(uristring);
    console.log('----data is fetched ------',data);
    const result = await data.data.result[0];
    console.log('-----data result -------');
    console.log(result);
    console.log('------end data result --------');
  

    //  console.log("-------------------SNOW RESULT--------", data);

    if (result) {
      console.log('-----result in ServiceNow ---', result);
      const isProcessable = await isTCRProcessable(tcrno, env, sysid, action,'','',application);
      console.log('----isProcessable ----', isProcessable);

      if(!isProcessable.status){
          publishMessageThatTCRAlreadyExecuted(isProcessable.execution_id, tcrno);
          return {error: isProcessable.message}; 
      }

      let newRecord = '';
      if(isProcessable.execution_id === null){
        console.log('---execution_id --- inc case of first time tcr validation ----');
        const exec_rec = await fetchExecutionId(tcrno, env, sysid, action, '', '', application);
        const [execution_id, , status, ,message , execution_code,,,,action_rec] = exec_rec;
        console.log('---execution_id --- inc case of first time tcr validation ----', execution_id);
        newRecord= execution_id;
      }else{
         newRecord = isProcessable.execution_id;
      }
     
      let res1 = { message: `Validating ${tcrno}`, error: [], tcrno }
      publishResponse('TCR_PROCESSING', 'tcrProcessing', res1);

      //Fetch affected service name 
       const affected_service = await getAffectedService(result.u_affected_service.value);
      console.log('----application :  ',application);
      console.log('----result.u_affected_service_value -----', result.u_affected_service.value);
      if (result.u_affected_service.value !== application) {
        console.log("---affected_service, application --", result.u_affected_service.value, application);
        let res2 = { message: '', error: [`Affected service ${application} is not mapped to ${tcrno}`], tcrno };

        publishResponse('TCR_PROCESSING', 'tcrProcessing', res2);
        await updateExecutionStatusDetail(newRecord, tcrno, APPLICATION_NOT_MAPPED_WITH_USER, sysid, application, env, APPLICATION_NOT_MAPPED_WITH_USER_MSG);
        await updateExecutionStatusOnly(newRecord, EXECUTION_FAILED, `Affected service ${application} is not mapped to ${tcrno}`, TCR_PROCESSING_RETRYABLE);
        return { error: `TCR not mapped with application` };
      }
      else {

        const start_date = result.start_date;
        const end_date = result.end_date;
        const tcrstate = await getTCRState(result.state);
        const mcr = await getMCRInfo(result.parent.value);
        const change_raiser = await getChangeRaiser(result.u_change_raiser.value);
        const assignment_team = await getAssignmentTeam(result.assignment_group.value);
        const assignee_info = await getAssigneeInfo(result.assigned_to.value);
        if(result.implementation_plan=== '' || result.implementation_plan === undefined){
           console.log('----Implementation plan is not available -----');
           let res2 = { message: '', error: [`Implementation Plan not available for  ${tcrno}`], tcrno };

           publishResponse('TCR_PROCESSING', 'tcrProcessing', res2);
          await updateExecutionStatusDetail(newRecord, tcrno, IMPLEMENTATION_PLAN_NOT_AVAILABLE, sysid, application, env, `Implementation Plan not available for  ${tcrno}`);
           await updateExecutionStatusOnly(newRecord, EXECUTION_FAILED, `Implementation Plan not available for  ${tcrno}`, TCR_PROCESSING_RETRYABLE);
           return {error :`Implementation Plan not available for  ${tcrno}`}
        }
        const repository = getRepositoryPath(result.implementation_plan);
        const emails = addNotifier(result.implementation_plan);

        const records = {
          mcr: { ...mcr, state: result.u_mcr_state },
          tcr: { state: tcrstate, number: tcrno },
          repository: repository,
          emails,
          assignment_team,
          start_date,
          end_date,
          assignee_info,
          change_raiser,
          affected_service,
          curtime,
          issue: "OK"
        };
        console.log('---records constructed ----', records);
        //1. Validating TCR Result status 
        const isApproved = await isTCRApproved(result.state, tcrno, newRecord, sysid);
        if (!isApproved) {
          return { error: `TCR No:: ${tcrno} state is not approved.` };
        }

        //2. Validating the TCR Date and status and see if we can proceed with the further execution
        const isDateValid = await isTCRDateValid(result.start_date, result.end_date, tcrno, newRecord, sysid);
        if (!isDateValid) {
          return { error: `TCR No: ${tcrno} is not within a valid time frame` }
        }

        //3. Validating the TCR from the non prod execution 
        const flag = await isTCRProcessingAllowedBasedONonProdExecutionStatus(tcrno, env, sysid, action, repository.version, repository.repo);
         if(!flag){
          return { error: `${tcrno}: No successful deployment in non-production environment ` }
         }

        let msg =
        {
          message: `${tcrno} successfully validated. Proceeding with ansible package checkout....`,
          error: [],
          tcrno
        }

        publishResponse('TCR_PROCESSING', 'tcrProcessing', msg);
        const status2 = await updateExecutionStatusDetail(newRecord, tcrno, TCR_VALIDATED_SUCCESSFULLY, sysid, application, env, `${tcrno} successfully validated. Proceeding with ansible package checkout....`);
        const status22 = await updateExecutionStatusWithRepositoryInfo(newRecord, repository.repo, repository.version );

        const status = await checkout(
          repository,
          tcrno,
          env,
          action,
          curtime,
          records,
          sysid,
          application
        );

        let resp = {
          message: `Checkout of repository ${repository.repo} corresponding to tcrno: ${tcrno} completed`,
          error: [],
          tcrno
      }
      publishResponse('TCR_PROCESSING','tcrProcessing', resp);
      const status3 = await updateExecutionStatusDetail(newRecord, tcrno, CODE_CHECKOUT_COMPLETED, sysid, application, env,CODE_CHECKOUT_COMPLETED_MSG);
        return records;
      }

    } else {
      console.error(`TCR No ${tcrno} is invalid`);
      return { error: `AP TCR No:: ${tcrno} is invalid` };
    }
  } catch (error) {
    console.log("error 123 ---", error);
    console.log(`error4545: ${error.error}`);
    log.log("error", `Error Fetching the Information for ${tcrno} `);
    log.log("error", `${error}`);

    throw new Error({ error: `Error Fetching the Information for ${tcrno} ` });
  }
};

const getTCRState = async state => {
  console.log("In getTCRState", state);
  const tcrstat = await executeStatement(
    "select status from snowchangestatus where value = :state",
    state
  );
  console.log(tcrstat, "tcrstat");
  const tstatus = tcrstat.rows[0][0];
  console.log(tstatus, "tstatus");
  return tstatus;
};

const getMCRInfo = async parent => {
  // console.log("---In getMCRInfo ---", parent);
  const uristring = `/now/table/task?sysparm_query=sys_id=${parent}&sysparm_fields=number`;
  try {
    const mcrinfo = await instance.get(uristring);
    // console.log('----getMCRInfo ----', mcrinfo);
    let mcrnumber = mcrinfo.data.result;
    return mcrnumber[0] || {};
  } catch (error) {
    log.log("error", `Error while fetching MCR information for: ${mcrnumber}`);
    console.error(
      `Error while fetching MCR information for parent ${parent} : `,
      error
    );
  }
  return {};
};

const getAssigneeInfo = async assignee_id => {
  console.log("---In getAssigneeInfo ---", assignee_id);
  const uristring = `/now/table/sys_user?sysparm_query=sys_id=${assignee_id}&sysparm_fields=u_full_name%2Cemail`;

  try {
    const assignee = await instance.get(uristring);
    //  console.log('---assignee---', assignee.data.result);
    let assignee_info = assignee.data.result;
    return assignee_info[0] || {};
  } catch (error) {
    log.log(
      "error",
      `Error while fetching Assignee information for: ${assignee_id}`
    );

    console.error(
      `Error while fetching Assignee information for change assignee id  ${assignee_id} : `,
      error
    );
  }
  return {};
};

const getAssignmentTeam = async assignmentTeam => {
  console.log("---In getAssignmentTeam ---", assignmentTeam);
  const uristring = `/now/table/sys_user_group?sysparm_query=sys_id=${assignmentTeam}&sysparm_fields=name`;
  try {
    const assignment_team = await instance.get(uristring);
    let assignment_team_info = assignment_team.data.result;
    return assignment_team_info[0] || {};
  } catch (error) {
    log.log(
      "error",
      `Error while fetching Assignment Team information for: ${assignmentTeam}`
    );
    console.error(
      `Error while fetching Assignmet Team information for change assignmentTeam  ${assignmentTeam} : `,
      error
    );
  }
  return {};
};

const getChangeRaiser = async change_raiser_id => {
  console.log("---In getChangeRaiser ---", change_raiser_id);
  const uristring = `/now/table/sys_user?sysparm_query=sys_id=${change_raiser_id}&sysparm_fields=u_full_name%2Cemail`;
  //console.log(`uristring: ${uristring}`);
  try {
    const change_raiser = await instance.get(uristring);
    // console.log('---change_raiser---', change_raiser.data.result);
    let change_raiser_info = change_raiser.data.result;
    return change_raiser_info[0] || {};
  } catch (error) {
    log.log(
      "error",
      `Error while fetching Change Raiser information for change raiser id  ${change_raiser_id}`
    );

    console.error(
      `Error while fetching Change Raiser information for change raiser id  ${change_raiser_id} : `,
      error
    );
  }
  return {};
};

const getAffectedService = async affectedservice => {
  console.log("---In getAffectedService ---", affectedservice);
  const uristring = `/now/table/cmdb_ci?sysparm_query=sys_id=${affectedservice}&sysparm_fields=name`;
  //console.log(`uristring: ${uristring}`);
  try {
    const affected_service = await instance.get(uristring);
    console.log("---affected_service-656565--", affected_service.data.result);
    let affected_service_info = affected_service.data.result;
    console.log('----affected_service_info ----', affected_service_info);
    return affected_service_info[0] || {};
  } catch (error) {
    log.log(
      "error",
      `Error while fetching Affected Service information for affected service :${affectedservice}`
    );
    console.error(
      `Error while fetching Affected Service information for affected service  ${affectedservice} : `,
      error
    );
  }
  return {};
};

module.exports = {
  getMCRInfo,
  getAssigneeInfo,
  getAssignmentTeam,
  getChangeRaiser,
  getAffectedService,
  getServiceNowInfo
};
