const { executeStatement, executeStatementWithObjectParams}  = require('../db/db');
const {instance} = require('./common');

const addNewUser =async  (user) => {

    const uri = `/now/table/sys_user?sysparm_query=email=${user.email}&active=true&sysparm_fields=u_full_name%2Cemail%2Csys_id`;
    try {
        let result = await instance.get(uri);
        console.log('---User detail -----', result.data.result[0]);
        let sys_id = result.data.result[0].sys_id;
        let app_admin =  user.normal? 'Y': 'N';
        let prod = 'N';
        let nonprod = 'Y';
        if (app_admin ==='Y') {
            prod = 'Y';
            nonprod = 'Y'
        }
        let user_role = {
                        sys_id: sys_id,
                        star_app_id: user.application,
                        app_admin: app_admin,
                        prod: prod,
                        nonprod: 'Y',
                        vault: 'Y',
                        app_instance_id: user.application
                    }
        console.log('---sys_id----', sys_id);
        const check_user = await executeStatement(`select * from STAR_USER WHERE sys_id =:sys_id`,sys_id);
         console.log('----check_user-----',check_user);
        if(check_user.rows && check_user.rows.length > 0){
            const existing_user = check_user.rows.map(item => {
                return {
                    sys_id: item[0],
                    email: item[2]
                }
            })
            console.log('--User Exists----', existing_user);
           
            const new_user_role = await executeStatementWithObjectParams(`INSERT INTO STAR_USER_ROLE (SYS_ID, STAR_APP_ID, APP_ADMIN, PROD, NON_PROD, VAULT, APP_INSTANCE_SYS_ID) VALUES (:sys_id, :star_app_id, :app_admin, :prod, :nonprod, :vault, :app_instance_id)`, {
                ...user_role
            } );
           console.log('---New User Role Created for existing user ----', new_user_role);
           return {
            message: 'User was added'
        }

        }else {
        const new_user = await executeStatementWithObjectParams(`INSERT INTO STAR_USER (SYS_ID, NAME, EMAIL, PASSWORD, SYS_ADMIN, APP_ADMIN) VALUES (:sys_id, :name, :email, :password, :sys_admin, :app_admin)`, {
            sys_id: sys_id, //TODO instead of application this should be fetched from the service now
            name: user.name,
            email: user.email,
            password: user.password,
            sys_admin: user.sysadmin? 'Y':'N',
            app_admin: app_admin
        } );
       
        console.log('---result ---', new_user);
        if(new_user.rowsAffected != 1){
            throw new Error('User was not added');
        }
        else {
            console.log('New User was added');
    
            // const user_role = {
            //     sys_id: sys_id,
            //     star_app_id: user.application,
            //     app_admin: app_admin,
            //     prod: prod,
            //     nonprod: 'Y',
            //     vault: 'Y',
            //     app_instance_id: sys_id
            // }
            const new_user_role = await executeStatementWithObjectParams(`INSERT INTO STAR_USER_ROLE (SYS_ID, STAR_APP_ID, APP_ADMIN, PROD, NON_PROD, VAULT, APP_INSTANCE_SYS_ID) VALUES (:sys_id, :star_app_id, :app_admin, :prod, :nonprod, :vault, :app_instance_id)`, {
                ...user_role
            } );
           console.log('---new_user_role ----', new_user_role);

            return {
                message: 'User was added'
            }
        }
      }
    } catch (error) {
        console.log('---Error Fetching User Information from ServiceNow for email id ', user.email);
        console.error('---Errror is -----', error);
        throw new Error(`No user exists in ServiceNow for the email ${user.email}`);
    }

    
}


const resetPassword =  async (user) => {
    const result = await executeStatementWithObjectParams(`update star_user set password = :password where email= :email`,{
        email: user.email,
        password: user.password
    });
    console.log('---User is ----',result);
    if(result.rowsAffected === 1){
        console.log('---User password was changed---');
        return {
            message: 'Password was changed',
            success: true
        }
    }else{
        throw new Error('----User is not available in System---');
    }
}

module.exports = {addNewUser, resetPassword};