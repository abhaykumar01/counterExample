const { executeStatement, execute}  = require('../db/db');

exports.getlogs = async( req ) =>{
    const auditlogs = await executeStatement(`SELECT STAR_USER.name, STAR_USER.email, STAR_EXECUTION_STATUS.message, STAR_EXECUTION_STATUS.revision, STAR_EXECUTION_STATUS.repo_path, STAR_EXECUTION_STATUS.ENVIRONMENT,
    STAR_EXECUTION_STATUS.app_instance_sys_id, STAR_EXECUTION_STATUS.tags, STAR_APPS.app_name FROM STAR_USER JOIN STAR_EXECUTION_STATUS ON STAR_EXECUTION_STATUS.SYS_ID = STAR_USER.SYS_ID JOIN
    STAR_APPS ON STAR_APPS.app_instance_sys_id = STAR_EXECUTION_STATUS.app_instance_sys_id WHERE STAR_USER.SYS_ID =:sys_id`,req.body.sysId);
    //console.log('---reseult set  ----', auditlogs.rows);
    var MainAray = []
    if(auditlogs.rows.length > 0 ){
        for ( var i=0; i<auditlogs.rows.length; i++){
            var curr = auditlogs.rows[i];
            MainAray.push({
                name:curr[0],
                email:curr[1],
                message:curr[2],
                revision:curr[3],
                repopath:curr[4],
                env:curr[5],
                appsysid:curr[6],
                tags:curr[7],
                appname:curr[8]
            })
        }
        return MainAray;
       
    }else{
        return {
            'message': 'No data found'
        }
    }

}
