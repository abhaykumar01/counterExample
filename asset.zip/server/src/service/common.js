const axios = require("axios");

const instance = axios.create({
    baseURL: process.env.NODE_PROD_SERVICE_NOW_URL,
    timeout: 3000,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      Authorization:
        "Basic " +
        Buffer.from(process.env.NODE_PROD_SERVICE_NOW_USER + ":" + process.env.NODE_PROD_SERVICE_NOW_PASSWORD).toString("base64"),
      "Access-Control-Allow-Headers":
        "Origin, X-Requested-With, Content-Type, Accept"
    }
  });

  module.exports = {instance}