const shell = require("child_process").exec;
const simplecrypt = require('simplecrypt');
const moment = require('moment');
const fs = require('fs');
const logger = require('./Logger');
const readline = require('readline');
const net = require('net');
const { fetchServerInfo } = require('./service/ConfigurationService');
const { svncheckout } = require("./service/SVNService");
const { cloneGIT } = require("./service/GITService");
const { publishResponse } = require('./graphql/publish');
const { executeStatementWithObjectParams } = require('./db/db');
const { CODE_CHECKOUT_INITIATED,
	CODE_CHECKOUT_COMPLETED,
	CMDB_VERIFICIATION_INITIATED,
	CMDB_ERROR_READING_FILE,
	CMDB_VERIFICATION_SUCCESSFUL,
	CMDB_VERIFICATION_UNSUCCESSFUL,
	EXECUTION_FAILED,
	TCR_PROCESSING_RETRYABLE,
	TCR_EXECUTION_IN_PROGRESS,
	TCR_PROCESSING_FREEZED } = require('./constant/executionstate');
const { CODE_CHECKOUT_INITIATED_MSG, CODE_CHECKOUT_COMPLETED_MSG,
	CMDB_VERIFICIATION_INITIATED_MSG,
	CMDB_VERIFICATION_SUCCESSFUL_MSG } = require('./constant/executionmessage');

const _ = require('lodash');

const environmentMaps = new Map();
environmentMaps.set('Production', 'PROD');
environmentMaps.set('Development', 'DEV');
environmentMaps.set('Test', 'Test');

const getRepositoryPath = (text) => {
	console.log('---text----', text);
	let repo_section = text.split("<star>");
	let repo_details = repo_section[1].replace(/(\r\n|\n|\r)/gm, "").split(",");

	let repo_obj = {};
	for (var i = 0; i < repo_details.length; i++) {
		var split = repo_details[i].split(':');
		repo_obj[split[0].trim()] = split[1].trim();
	}

	return repo_obj;
}

const addNotifier = (text) => {
	try {
		let notifier_section = text.split("<notifier>");
		console.log('---notifier_section ----', notifier_section[1]);
		return notifier_section[1];
	} catch (error) {
		console.error('--Error matching the notifier section ', error);
		throw new Error(`Error matching notifier section --${error}`);
	}

}

const sendEmail = (script, logfile, assignee_email) => shell(script, logfile, assignee_email
	,
	(error, stdout, stderr) => {
		console.log(stdout);
		console.log(stderr);
		if (error !== null) {
			console.log(`exec error: ${error}`);
		}
	}
);

const encrypt = (text) => {
	const sc = simplecrypt();
	const digest = sc.encrypt(text);
	console.log('---digest----', digest);

	const message = sc.decrypt(digest);
	console.log('---message----', message);
}

const decrypt = (text) => {
	const sc = simplecrypt();
	return sc.decrypt(text);
}


const validateDate = (start_date, end_date) => {
	var nowDate = new Date();
	var currentDate = moment(nowDate);

	var mstartDate = moment(start_date);
	var mendDate = moment(end_date);

	if (moment(currentDate).isBetween(mstartDate, mendDate)) {
		console.log('Change window Validated');
		return true;
	}
	else {
		console.log('Change Outside Change Window');
		return false;
	}
}

const validateTcrStat = (tcrstatus) => {
	//tcrstatus === '-2'
	if (tcrstatus === '-2' || tcrstatus === '1') {
		console.log('TCR is scheduled state');
		return true;
	}
	else {
		console.log('TCR is not in scheduled state');
		return false;
	}
}

const readLines = (file, onLine, errorHandler) => {
	console.log('----in readLines method ----', file);

	const reader = readline.createInterface({
		input: fs.createReadStream(file),
		crlfDelay: Infinity
	});

	reader.on('line', onLine);
	reader.on('error', errorHandler);

	return new Promise(resolve => reader.on('close', resolve));
};

const readFile = async (file) => {
	console.log('----in readFile ----', file);
	const lines = [];
	let errors = {};
	if (fs.existsSync(file)) {
		console.log('----file exists -----');
	} else {
		console.log('---file doest not exist ----');
		throw new Error(`${file} does not exist`);
	}
	await readLines(file, line => {
		if (!line.startsWith('[')) {
			if (line !== '') {
				let temp = line.split(' ');
				console.log('--temp---', temp);
				lines.push(temp[0]);
			}

		}
	},
		error => {
			console.error('---Error reading the file ----', error);
			errors = { ...error };
			console.log('---errors ---', errors);
		}
	);
	let validAddresses = lines.map(item => {
		if (net.isIP(item) === 4) return item;
		if (item.indexOf('.') !== -1) {
			let str = item.substring(0, item.indexOf('.'));

			return str;
		}
		return item;
	}).filter(item => item.length > 8);
	console.log('--lines--', lines);
	console.log('---validAddresses--', validAddresses);
	return validAddresses;
}

const verifyServersAssociatedWithEnvironment = async (filepath, environment, app, tcrno, sysid, action, srcrevision, svnrepo) => {
	console.log('----verifyServerAssosciatedWithEnvironment ----', filepath, environment, app, tcrno, action, srcrevision, svnrepo);
	//need to pass the other attributes
	console.log('---Going to calll the fetchExecutionId from verfifyServerAssociatedWithEnvironment');
	const rec = await fetchExecutionId(tcrno, environment, sysid, action, srcrevision, svnrepo, app);
	console.log('---rec ----', rec);
	let line = [];
	let res = {
		message: `${tcrno}: ${CMDB_VERIFICIATION_INITIATED_MSG}`,
		error: [],
		tcrno
	}
	publishResponse('TCR_PROCESSING', 'tcrProcessing', res);
	const status1 = await updateExecutionStatusDetail(rec[0], tcrno, CMDB_VERIFICIATION_INITIATED, sysid, app, environment, CMDB_VERIFICIATION_INITIATED_MSG);
	try {
		line = await readFile(filepath + '/inventories/' + environment + '/hosts');
		console.log('---line ---', line);
	} catch (err) {
		console.log('---Error while reading the file ', err);
		let res = {
			message: '',
			error: [`${tcrno}:Error reading the file - ${err}`],
			tcrno
		}
		publishResponse('TCR_PROCESSING', 'tcrProcessing', res);
		const status2 = await updateExecutionStatusDetail(rec[0], tcrno, CMDB_ERROR_READING_FILE, sysid, app, environment, `${tcrno}:Error reading the file - ${err}`);
		const status = await updateExecutionStatus(rec[0], EXECUTION_FAILED, `${tcrno}:Error reading the file - ${err}`, TCR_PROCESSING_RETRYABLE, action);
		throw new Error(`${tcrno}:  ${err}`)
		//  return {error: `${tcrno}:Error reading the file - ${err}`}
	}

	try {
		const result = await fetchServerInfo(environment, app);
		console.log('---servers ---', result);
		if (result && result.rows && result.rows.length > 0) {

			const isVerified = await validateWhetherServersInHostFileArePartOfEnvironmentOrNot(line, result.rows, tcrno, sysid, app, environment, rec[0], action);
			if (isVerified) {
				res = {
					message: `${tcrno}: ${CMDB_VERIFICATION_SUCCESSFUL_MSG}`,
					error: [],
					tcrno
				}
				publishResponse('TCR_PROCESSING', 'tcrProcessing', res);

				const status3 = await updateExecutionStatusDetail(rec[0], tcrno, CMDB_VERIFICATION_SUCCESSFUL, sysid, app, environment, CMDB_VERIFICATION_SUCCESSFUL_MSG);
				return null;
			}
			else {
				res = {
					message: '',
					error: [`${tcrno}:No Server records exist for the environment and application in the database`],
					tcrno
				}
				publishResponse('TCR_PROCESSING', 'tcrProcessing', res);
				throw new Error(`${tcrno}:  No Server records exist for the environment and application in the database`);
				// return {error: `${tcrno}: No Server records exist for the environment and application in the database`}	 
			}
		} else {
			console.log('---No Server records are available for the environment and application in the database ');
			res = {
				message: '',
				error: [`${tcrno}:No Server records exist for the environment and application in the database`],
				tcrno
			}
			publishResponse('TCR_PROCESSING', 'tcrProcessing', res);
			throw new Error(`${tcrno}:  No Server records exist for the environment and application in the database`);
		}

	} catch (error) {
		console.log(`---Error fetching server information for env:  ${environment} and app: ${app}. Error is : ${error}`);
		const status3 = await updateExecutionStatusDetail(rec[0], tcrno, CMDB_VERIFICATION_UNSUCCESSFUL, sysid, app, environment, `---Error fetching server information for env:  ${environment} and app: ${app}. Error is : ${error}`);
		throw new Error(`${tcrno}:Error Verifying the server information - ${error}`);
	}

}

const validateWhetherServersInHostFileArePartOfEnvironmentOrNot = async (serversFromFile, serversFromDatabase, tcrno, sysid, app, environment, execution_id, action) => {
	let serversFromDb = serversFromDatabase.map(server => server[0]);
	console.log('----serversFromDB------', serversFromDb);
	console.log('----serversFromFile------', serversFromFile);

	let errors = [];
	let serversNotFound = serversFromFile.filter(s => {
		if (!_.includes(serversFromDb, s)) {
			return true;
		}
		return false;
	})
	console.log('----serversNotFound------', serversNotFound);
	if (serversNotFound && serversNotFound.length > 0) {
		let res1 = {
			message: '',
			error: [`${tcrno}: Servers in host file ${serversNotFound} is not matching with CMBD data `],
			tcrno
		};
		publishResponse('TCR_PROCESSING', 'tcrProcessing', res1);
		const status3 = await updateExecutionStatusDetail(execution_id, tcrno, CMDB_VERIFICATION_SUCCESSFUL, sysid, app, environment, CMDB_VERIFICATION_SUCCESSFUL_MSG);
		const status2 = await updateExecutionStatus(execution_id, EXECUTION_FAILED, `${tcrno} : Servers in host file ${serversNotFound} is not matching with CMBD data`, TCR_PROCESSING_FREEZED, action);
		return false;
	}
	return true;
}

const checkout = async (repo, tcrno, env, action, curtime, records, sysid, app_instance_id) => {
	console.log("--In util checkout (repo)", repo);
	console.log("--In util checkout ()", tcrno, env, action, curtime, sysid, app_instance_id);
	console.log("--In util checkout Going to call fetchExecutionId");
	const rec = await fetchExecutionId(tcrno, env, sysid, action, repo.version, repo.repo, app_instance_id);
	console.log('--Util checkout-rec ----', rec);
	
	const log = logger(tcrno,curtime);
    log.log({
      level: "info",
      message: `Checkout for ${tcrno} : Repo ${repo} : ${action}.`
    });
	
	let res1 = {
		message: `${tcrno}: Going to checkout code.`,
		error: [],
		tcrno
	};
	publishResponse('TCR_PROCESSING', 'tcrProcessing', res1);
	const status1 = await updateExecutionStatusDetail(rec[0], tcrno, CODE_CHECKOUT_INITIATED, sysid, app_instance_id, env, CODE_CHECKOUT_INITIATED_MSG);

	if (repo.sys === "SVN" || repo.sys === 'svn') {

		const status = await svncheckout(repo, tcrno, curtime, records);
		if (status.error) {
			console.log('----Error in Checking out SVN repository-----');
		} else {
			console.log('----No Error in Checking out SVN repository-----');
		}

		return status;

	} else {
		const status = await cloneGIT(
			repo,
			tcrno,
			env,
			action,
			curtime,
			records,
			sysid,
			app_instance_id,
			rec[0]
		);
		let res3 = {
			message: `${tcrno}: Code Checkout Completed.`,
			error: [],
			tcrno
		};
		// publishResponse('TCR_PROCESSING', 'tcrProcessing', res3);
		console.log('--util checkout -status of git clone operation after cloning operation ----', status);
		return status;
	}
}

const updateExecutionStatusDetail = async (execution_id, tcrno, stage, user_id, app_instance_id, environment, message) => {
	console.log('---param in updateExecutionStatusDetail ---', tcrno, stage, user_id);
	console.log('----execution_id---', execution_id);
	console.log('----app_instance_id---', app_instance_id);
	console.log('----environment----', environment);
	console.log('----message----', message);
	try {
		let query = `INSERT INTO STAR_EXECUTION_STATUS_DETAILS (execution_id, TCRNO, STAGE,  EXECUTED_AT, SYS_ID, APP_INSTANCE_SYS_ID, ENVIRONMENT, MESSAGE ) VALUES (:execution_id, :tcrno, :stage, :executed_at, :sys_id, :app_instance_sys_id, :environment, :message )`;
		const result = await executeStatementWithObjectParams(query, {
			execution_id: execution_id,
			tcrno: tcrno,
			stage: stage,
			executed_at: new Date(),
			sys_id: user_id,
			app_instance_sys_id: app_instance_id,
			environment: environment,
			message: (message && message !== null) ? message.toString().substring(0, 240) : ''
		})

		console.log('---result updateExecutionStatusDetails ----', result);
		if (result.rowsAffected != 1) {
			console.error('--Error Updating the Execution status detail--result-', result);
		}
	} catch (error) {
		console.error('--Error Updating the Execution status Details---', error);
		throw new Error(error);
	}
}

const updateExecutionStatus = async (execution_id, status, message, execution_code, action) => {
	console.log('---param in updateExecutionStatus ---', execution_id);
	console.log('----status---', status);
	console.log('----message----', message);
	try {
		let query = `UPDATE STAR_EXECUTION_STATUS  SET STATUS = :status, MESSAGE = :message , EXECUTION_CODE = :execution_code, action =:action where id = :execution_id`;
		const result = await executeStatementWithObjectParams(query, {
			status: status,
			message: (message && message !== null) ? message.toString().substring(0, 240) : '',
			execution_id: execution_id,
			execution_code: execution_code && execution_code !== null ? execution_code : TCR_PROCESSING_FREEZED,
			action: action
		})

		console.log('---result updateExecutionStatus ----', result);
		if (result.rowsAffected != 1) {
			console.error('--Error Updating the Execution status--result-', result);
		}
	} catch (error) {
		console.error('--Error Updating the Execution status---', error);
		throw new Error(error);
	}
}



const parseArrayAsString = tags => {
	if (tags && tags.length > 0) {
		let tagstring = ''
		for (const rec of tags) {
			tagstring +=rec+','
		}
		console.log('---tagstring --',tagstring);
		let abc = tagstring.substring(0,tagstring.lastIndexOf(',')).trim();
		console.log('---tagstring modified ----',abc);
		return abc;
	}
}
const updateExecutionStatusWithTags = async (execution_id, status, message, execution_code, action, tags) => {
	console.log('---param in updateExecutionStatusTags ---', execution_id);
	//Note here the value of tags comes as ['all'] or  [ 'tagapp', 'webservertag' ], so we need to parse this as string
	console.log('----tags---', tags);
	let modifiedTags = parseArrayAsString(tags);
	try {
		let searchQuery = `SELECT id, tags from STAR_EXECUTION_STATUS where id =:execution_id`;

		const searchResults = await executeStatementWithObjectParams(searchQuery, { execution_id: execution_id });
		console.log('---searchResults----', searchResults);
		if (searchResults && searchResults.rows.length > 0) {
			console.log('----searchResults rows[0]: ', searchResults.rows[0]);
			console.log('----searchResults rows[0][1]: ', searchResults.rows[0][1]);
			if (searchResults.rows[0][1] !== null) {
				let new_tags = modifiedTags === 'all'?modifiedTags :searchResults.rows[0][1] + ',' + modifiedTags;
				console.log('---new_tags----', new_tags);
				let query = `UPDATE STAR_EXECUTION_STATUS  SET STATUS = :status, MESSAGE = :message , EXECUTION_CODE = :execution_code, action =:action,  TAGS = :new_tags where id = :execution_id`;
				const result = await executeStatementWithObjectParams(query, {
					new_tags: new_tags,
					execution_id: execution_id,
					status: status,
					message: (message && message !== null) ? message.toString().substring(0, 240) : '',
					execution_code: execution_code && execution_code !== null ? execution_code : TCR_PROCESSING_FREEZED,
					action: action
				});
				console.log('---result updateExecutionStatusTags ----', result);
				if (result.rowsAffected != 1) {
					console.error('--Error Updating the Execution tags--result-', result);
				}
			}
			else {
				console.log('----Going to modify the tags field --- else block');
				let query = `UPDATE STAR_EXECUTION_STATUS  SET STATUS = :status, MESSAGE = :message , EXECUTION_CODE = :execution_code, action =:action, TAGS = :new_tags where id = :execution_id`;
				const result = await executeStatementWithObjectParams(query, {
					new_tags: modifiedTags,
					status: status,
					message: (message && message !== null) ? message.toString().substring(0, 240) : '',
					execution_id: execution_id,
					execution_code: execution_code && execution_code !== null ? execution_code : TCR_PROCESSING_FREEZED,
					action: action
				});
				console.log('---result updateExecutionStatusTags ----', result);
				if (result.rowsAffected != 1) {
					console.error('--Error Updating the Execution tags--result-', result);
				}
			}
		}
	} catch (error) {
		console.error('--Error Updating the Execution status tags---', error);
		throw new Error(error);
	}
}

const updateExecutionStatusWithRepositoryInfo = async (execution_id, repo_path, revision) => {
	console.log('---param in updateExecutionStatusWithRepositoryInfo ---', execution_id);
	console.log('----repo_path, revision, action---', repo_path, revision);
	try {
		let query = `UPDATE STAR_EXECUTION_STATUS  SET REPO_PATH = :repo_path, REVISION = :revision  where id = :execution_id`;
		const result = await executeStatementWithObjectParams(query, {
			execution_id: execution_id,
			repo_path: repo_path || '',
			revision: revision || ''
		})

		console.log('---result updateExecutionStatusWithRepositoryInfo ----', result);
		if (result.rowsAffected != 1) {
			console.error('--Error updateExecutionStatusWithRepositoryInfo Updating the Execution status--result-', result);
		}
	} catch (error) {
		console.error('--Error updateExecutionStatusWithRepositoryInfo Updating the Execution status---', error);
		throw new Error(error);
	}
}

const updateExecutionStatusOnly = async (execution_id, status, message, execution_code) => {
	console.log('---param in updateExecutionStatusOnly ---', execution_id);
	console.log('----status---', status);
	console.log('----message----', message);
	try {
		let query = `UPDATE STAR_EXECUTION_STATUS  SET STATUS = :status, MESSAGE = :message , EXECUTION_CODE = :execution_code where id = :execution_id`;
		const result = await executeStatementWithObjectParams(query, {
			status: status,
			message: (message && message !== null) ? message.toString().substring(0, 240) : '',
			execution_id: execution_id,
			execution_code: execution_code && execution_code !== null ? execution_code : TCR_PROCESSING_FREEZED,

		})

		console.log('---result updateExecutionStatusOnly ----', result);
		if (result.rowsAffected != 1) {
			console.error('--Error Updating theupdateExecutionStatusOnly Execution status--result-', result);
		}
	} catch (error) {
		console.error('--Error UpdatingupdateExecutionStatusOnly the Execution status---', error);
		throw new Error(error);
	}
}

const createNewExecutionStatusRecord = async (tcrno, status, user_id, message, action, revision, repo_path, environment, app_instance_sys_id) => {
	console.log('---param in createNewExecutionStatusRecord ---', tcrno, status, user_id);
	console.log('----status---', status);
	console.log('----action, revision, repo_path-- environment,app_instance_sys_id--', action, revision, repo_path, environment, app_instance_sys_id);
	try {
		let query = `INSERT INTO STAR_EXECUTION_STATUS (TCRNO, STATUS,  EXECUTED_AT, SYS_ID, MESSAGE, EXECUTION_CODE, REVISION, REPO_PATH, ACTION , ENVIRONMENT, APP_INSTANCE_SYS_ID) VALUES ( :tcrno, :status, :executed_at, :sys_id, :message, :execution_code, :revision, :repo_path, :action , :environment, :app_instance_sys_id)`;
		const result = await executeStatementWithObjectParams(query, {
			tcrno: tcrno,
			status: status,
			executed_at: new Date(),
			sys_id: user_id,
			message: message !== null ? message.toString().substring(0, 240) : '',
			execution_code: TCR_PROCESSING_RETRYABLE,
			revision: revision,
			repo_path: repo_path,
			action: action,
			environment: environment,
			app_instance_sys_id: app_instance_sys_id
		})

		console.log('---result createNewExecutionStatusRecord ----', result);
		if (result.rowsAffected != 1) {
			console.error('--Error Creating the Execution status--result-', result);
			return null;
		} else {
			let fetchquery = '';
			let newRecord = '';
			if (environment !== 'Production') {
				console.log('----Going to return the newly created record for Non Production scenario-----');
				fetchquery = `SELECT id, tcrno, status, executed_at, message, execution_code, revision, repo_path, action from STAR_EXECUTION_STATUS where tcrno = :tcrno  AND environment =:env and app_instance_sys_id =:app_instance_sys_id order by executed_at desc`;
				newRecord = await executeStatementWithObjectParams(fetchquery, {
					tcrno: tcrno,
					env: environment,
					app_instance_sys_id: app_instance_sys_id
				})

			} else {
				fetchquery = `SELECT id, tcrno, status, executed_at, message, execution_code, revision, repo_path, action from STAR_EXECUTION_STATUS where tcrno = :tcrno AND environment =:environment order by executed_at desc`;
				newRecord = await executeStatementWithObjectParams(fetchquery, {
					tcrno: tcrno,
					environment: environment
				})

			}

			console.log('---newRecord ----', newRecord);
			if (newRecord.rows.length > 0) {
				const rec = newRecord.rows[0];
				console.log('--rec ---', rec);
				return rec;
			}
		}
	} catch (error) {
		console.error('--Error Creaating the Execution status---', error);
		return null;
	}
}


const fetchExecutionId = async (tcrno, env, sysid, action, revision, repo_path, app_instance_id) => {
	console.log('---In fetchExecutionId ----', tcrno, env, sysid, action, revision, repo_path);
	try {

		if (env !== 'Production') {
			// find the record with given revision number. If it exists use it otherwise create a new record
			let selectquery = `SELECT id, tcrno, status, executed_at, message, execution_code, revision, repo_path, environment, action  from STAR_EXECUTION_STATUS where revision =:revision and environment =:env and app_instance_sys_id =:app_instance_id order by executed_at desc`;
			let selectedRecords = await executeStatementWithObjectParams(selectquery, {
				revision: revision,
				env: env,
				app_instance_id: app_instance_id
			});

			if (selectedRecords && selectedRecords.rows && selectedRecords.rows[0] && selectedRecords.rows[0].length > 0) {
				console.log('--fetchExecutionId-selectedRecords rows ----', selectedRecords.rows[0]);
				return selectedRecords.rows[0];
			} else {
				console.log('---This is a case of non prod with no prior Execution case for given revision----', selectedRecords);
				const newRecForNonProd = await createNewExecutionStatusRecord(tcrno, TCR_EXECUTION_IN_PROGRESS, sysid, TCR_EXECUTION_IN_PROGRESS, action, revision, repo_path, env, app_instance_id);
				console.log('---newly created record non prod----', newRecForNonProd);
				return newRecForNonProd;
			}

		}

		let query = `SELECT id, tcrno, status, executed_at, message, execution_code, revision, repo_path, environment, action  from STAR_EXECUTION_STATUS where tcrno =:tcrno and environment =:env order by executed_at desc`;
		const rec = await executeStatementWithObjectParams(query, {
			tcrno: tcrno,
			env: env
		});
		// console.log('--fetchExecutionId-rec ----', rec);

		if (rec && rec.rows && rec.rows[0] && rec.rows[0].length > 0) {
			console.log('--fetchExecutionId-rec rows ----', rec.rows[0]);
			return rec.rows[0];
		} else {
			console.log('---This is a case of prod with no prior TCR Processing----', rec);
			// if (!(env === 'Production' || env === 'PROD')) {
			const newRec = await createNewExecutionStatusRecord(tcrno, TCR_EXECUTION_IN_PROGRESS, sysid, TCR_EXECUTION_IN_PROGRESS, action, revision, repo_path, env, app_instance_id);
			console.log('---newly created record ----', newRec);
			return newRec;
			// }

		}
	} catch (error) {
		console.error('----Error fetching the Execution id ----', error);
		return null;
	}
}


const fetchExecutionIdFromTCRProcessable = async (tcrno, env, sysid, action, revision, repo_path, app_instance_id) => {
	console.log('---In fetchExecutionIdFromTCRProcessable fetchExecutionId ----', tcrno, env, sysid, action, revision, repo_path);
	try {


		let query = `SELECT id, tcrno, status, executed_at, message, execution_code, revision, repo_path, environment, action, tags  from STAR_EXECUTION_STATUS where tcrno =:tcrno and environment =:env order by executed_at desc`;
		const rec = await executeStatementWithObjectParams(query, {
			tcrno: tcrno,
			env: env
		});
		// console.log('--fetchExecutionId-rec ----', rec);

		if (rec && rec.rows && rec.rows[0] && rec.rows[0].length > 0) {
			console.log('--fetchExecutionId-rec rows ----', rec.rows[0]);
			return rec.rows[0];
		} else {
			console.log('---This is a case of  with no prior TCR Processing----', rec);
			return null;
		}
	} catch (error) {
		console.error('----Error fetching the Execution id ----', error);
		return null;
	}
}


const isTCRProcessingFeasibleBasedOnNonProdExecutionStatus = async (tcrno, env, sysid, action, revision, repo_path) => {
	console.log('---In isTCRProcessingFeasibleBasedOnNonProdExecutionStatus ----', tcrno, env, sysid, action, revision, repo_path);
	try {
		let query = `SELECT id, tcrno, status, executed_at, message, execution_code  from STAR_EXECUTION_STATUS where revision =:revision and repo_path =:repo_path and  status =:status order by executed_at desc`;
		const rec = await executeStatementWithObjectParams(query, {
			status: 'SUCCESSFUL',
			repo_path: repo_path,
			revision: revision
		});
		console.log('--fetchExecutionId-rec45454 ----', rec);

		if (rec && rec.rows && rec.rows[0] && rec.rows[0].length > 0) {
			console.log('--isTCRProcessingFeasibleBasedOnNonProdExecutionStatus-rec rows ----', rec.rows[0]);
			return true;
		} else {
			console.log('---else isTCRProcessingFeasibleBasedOnNonProdExecutionStatus TCR Processing----', rec);
			return false;
		}
	} catch (error) {
		console.error('----Error fetching the isTCRProcessingFeasibleBasedOnNonProdExecutionStatus ----', error);
		return false;
	}
}

module.exports = {
	getRepositoryPath,
	addNotifier,
	sendEmail,
	encrypt,
	decrypt,
	validateDate,
	validateTcrStat,
	verifyServersAssociatedWithEnvironment,
	checkout,
	environmentMaps,
	updateExecutionStatus,
	updateExecutionStatusDetail,
	createNewExecutionStatusRecord,
	fetchExecutionId,
	updateExecutionStatusWithRepositoryInfo,
	isTCRProcessingFeasibleBasedOnNonProdExecutionStatus,
	fetchExecutionIdFromTCRProcessable,
	updateExecutionStatusOnly,
	updateExecutionStatusWithTags
};


