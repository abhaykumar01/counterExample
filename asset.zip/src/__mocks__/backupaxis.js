module.exports = {
    get: jest.fn((url) => {
        if(url.includes('/servicenow/')){
            console.log('---Going to call servicenow api----');
        }
        return Promise.resolve({
            data: {
                tcr: 'TCR048895',
                status: true
            }
        })
    }),
    create: () => {
        return Promise.resolve({})
    }
}