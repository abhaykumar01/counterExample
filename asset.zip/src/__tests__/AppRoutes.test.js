import React from 'react';
import ReactDOM from 'react-dom';
import '@testing-library/jest-dom'
import {render, fireEvent, getByTestId, renderer} from '@testing-library/react';
import {BrowserRouter as Router} from 'react-router-dom';
import AppRoutes from '../routes/AppRoutes';

it("renders without crashing", () => {
    const div = document.createElement("div");
    ReactDOM.render(<Router><AppRoutes /></Router>, div);
    ReactDOM.unmountComponentAtNode(div);
})

