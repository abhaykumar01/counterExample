import React from 'react';
import {render, fireEvent} from '@testing-library/react';
import StarPage from '../../../components/star/StarPage';

describe('StarPage', () => {
    it('should render successfully without crash', ()=> {
        const {container}= render(<StarPage />);
    })
})