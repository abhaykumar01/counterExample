import { ApplicationReducer } from '../../reducers/application/ApplicationReducer';

describe('ApplicationReducer', () => {

    it('Loading Test',  () => {
         const result = ApplicationReducer([], {type: 'LOADING'});
         expect(result.loading).toBe(true);
    })

    it('LOADED Test', () => {
        const result = ApplicationReducer([], {
            type: 'LOADED',
            payload: ['App1', 'App2']
        });

        expect(result.loading).toBe(false);
        expect(result.applications.length).toBe(2);
    })

    it('Default action type', () => {
        const result = ApplicationReducer([], {
            type: ''
        });

        // expect(result.loading).toBe(false);
        expect(result).toMatchObject([]);
    })
})