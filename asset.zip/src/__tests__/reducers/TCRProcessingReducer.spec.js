import { TCRProcessingReducer } from "../../reducers/tcrprocessing/TCRProcessingReducer";

describe('TCRProcessingReducer', () => {

    it('default state ', () => {
        const result = TCRProcessingReducer([], {type: ''});
        expect(result).toMatchObject([]);
    })

    it('cleanup state ', () => {
        const result = TCRProcessingReducer([], {type: 'cleanup'});
        expect(result).toMatchObject([]);
    })

    
    it('tcrProcessing state ', () => {
        const result = TCRProcessingReducer([], {type: 'tcrProcessing', payload: {msg: 'Msg1'}});
        
        expect(result[0].seq).toEqual(1);
        expect(result[0].msg).toBe('Msg1');
    })
})