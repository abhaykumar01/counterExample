import { UserReducer, userInitialState, UserCreationReducer } from "../../reducers/user/UserReducer";

describe('UserReducer', () => {
    it('default', () => {
        const result = UserReducer({}, {type: ''});
        expect(result).toMatchObject({});
    })

    it('reset', () => {
        const result = UserReducer({}, {type: 'reset'});
        expect(result).toMatchObject(userInitialState);
    })

    it('input', () => {
        const result = UserReducer({}, {type: 'input', payload: {name: 'email', value: 'xyz@abc.com'}});
        expect(result.email).toBe('xyz@abc.com');
    })
    
    it('checkbox', () => {
        const result = UserReducer({}, {type: 'checkbox', payload: {name: 'sysadmin', checked: true}});
        expect(result.sysadmin).toBeTruthy();
    })

    it('error', () => {
        const result = UserReducer(userInitialState, {type: 'error', payload: {name: 'name', value: 'Name is mandatory'}});
        expect(result.errors.length).toEqual(1);
        expect(result.errors[0].name).toBe('Name is mandatory');
    })

    
    it('cssclass', () => {
        const result = UserReducer(userInitialState, {type: 'cssclass', payload: {name: 'name', value: 'success'}});
        expect(result.cssclass).toMatchObject({name: 'success'});       
    })
})

describe('UserCreationReducer', ()=> {
    it('default', () => {
        const result = UserCreationReducer({},{type: ''});
        expect(result).toMatchObject({message:'', success: false});
    })

    it('USER_NOT_ADDED', () => {
        const result = UserCreationReducer({},{type: 'USER_NOT_ADDED', payload: 'User already exists'});
        expect(result).toMatchObject({message:'User already exists', success: false});
    })

    it('USER_ADDED_SUCCESSFULLY', () => {
        const result = UserCreationReducer({},{type: 'USER_ADDED_SUCCESSFULLY', payload: {message: 'User added successfully'}});
        expect(result).toMatchObject({message:'User added successfully', success: true});
    })
})