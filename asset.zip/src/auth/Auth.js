import decode from 'jwt-decode';

class Auth {
    static authenticationUser(token) {
        localStorage.setItem('token', token);
    }

    static isUserAuthenticated(){
        return localStorage.getItem('token') !==null;
    }

    static deauthenticateUser(){
        localStorage.removeItem('token');
    }

    static getToken(){
        return localStorage.getItem('token');
    }

    static getDecodedToken() {
        try{
            const token = localStorage.getItem('token');
            const decoded = decode(token);
            console.log('----decoded ------',decoded);
            const {username} = decoded;
            return username;
        }catch(err){
            console.error('Error while decoding token');
        }
    }

    static getUserRole() {
        try{
            const token = localStorage.getItem('token');
            const decoded = decode(token);
            console.log('----decoded ------',decoded);
            const {role} = decoded;
            return role;
        }catch(err){
            console.error('Error while decoding token');
        }
    }

    static getUserSysId() {
        try{
            const token = localStorage.getItem('token');
            const decoded = decode(token);
            // console.log('----decoded ------',decoded);
            const {sys_id} = decoded;
            return sys_id;
        }catch(err){
            console.error('Error while decoding token');
        }
    }
    static isProdAccess() {
        try{
            const token = localStorage.getItem('token');
            const decoded = decode(token);
            // console.log('----decoded ------',decoded);
            const {prodaccess} = decoded;
            console.log('----prodaccess ----', prodaccess)
            return prodaccess;
        }catch(err){
            console.error('Error while decoding token');
        }
    }

}

export default Auth;