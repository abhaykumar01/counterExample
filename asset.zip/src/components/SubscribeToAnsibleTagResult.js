import React, { useState } from 'react';
import gql from 'graphql-tag';
import { Subscription } from 'react-apollo';
// import { executeAnsibleTasks } from '../service/ServiceNow';
import Select , { components } from 'react-select';
import Tooltip from '@atlaskit/tooltip';



const TAGS_PROCESSING_SUBSCRIPTION = gql`

  subscription onAnsibleTagsListInfo {
      tagsProcessing{
        svnrepo
        error
        svnrevision
        tags
        error
        tcrno
      }     
  }
`
const MultiValueLabel = props => {
  return (
    <Tooltip content={'Customise your multi-value label component!'}>
      <components.MultiValueLabel {...props} />
    </Tooltip>
  );
};


const SubscribeToAnsibleTagResult = (props) => {
  console.log('----SubscribeToAnsibleTagResult ---', props);
  const [values, setValues] = useState({
    svnpath: '',
    svnrevision: '',
    multiline: 'Controlled',
    errors: [{}],
    tag: props.tag
  });



  const handleChange = name => event => {
    console.log(`'---${name}-  : value : -'`, event.target.value);
    setValues({ ...values, [name]: event.target.value });
  };

  const handleChangeMultiple = event => {
    console.log('----handleChangeMultiple ----', event);
    let tags = [];
    if(event && event.length > 0){
      tags = event.map(tag => tag.value);
      setValues({...values, tag: tags });
      console.log('--tags---',tags);
    }
     props.updateAnsibleTags(tags);
  }

  // const executeTask = async (event) => {
  //   console.log('-----Going to execute Ansible Task --------', values.tag, props.action);
  //   //const result = await executeAnsibleTasks(values.tag);
  //   const result = await executeAnsibleTasks(props.srcsys, props.svnrepo, props.tcrno, props.action, props.environment, props.curtime, values.tag);
  // }


  return (<Subscription subscription={TAGS_PROCESSING_SUBSCRIPTION}>
    {({ data, loading, error }) => {
      if (loading) return null;

      console.log('----data in subscribeToAnsibleTagResult----', data.tagsProcessing);

      if (data && data.tagsProcessing) {
        const { tags, svnrepo, svnrevision, tcrno } = data.tagsProcessing;
        console.log('tags : -', tags);
        if (tags.length > 0) {
          console.log('SubscribeToAnsible() ---props ---', props);

          if ((tcrno && tcrno === props.tcrno) || (props.svnrepo === svnrepo && props.svnrevision === svnrevision)) {
              const tagsoption = tags.map(tag =>{ return {
                value: tag,
                label: tag
              };
             } );

            return <div className="row mt-1">
              <div className="col-3">
                <label  htmlFor="ansibletags">Ansible Tags</label>
              </div>
              <div className="col-9">
              <Select
                closeMenuOnSelect={false}
                components={{ MultiValueLabel }}
                styles={{
                  multiValueLabel: base => ({
                    ...base,
                    backgroundColor: 'purple',
                    color: 'white',
                  }),
                }}
                defaultValue={[]}
                isMulti
                options={tagsoption}
                onChange={handleChangeMultiple}
              />
              </div>
            </div>
          }
          else {
            return <p></p>
          }

        }
        else {
          return <p>No Tags Available</p>
        }
      }
      else {
        return <p>Loading...</p>
      }
    }
    }
  </Subscription>
  )
}

export default SubscribeToAnsibleTagResult;