import React, { useState } from 'react';
import gql from 'graphql-tag';
import { Subscription } from 'react-apollo';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';

const HEALTH_CHECK_PROCESSING = gql`

  subscription onHealthCheck {
    healthCheckProcessing{
        message
        error
        tcrno
      }     
  }
`

const SubscribeToHealthCheck = (props) => {

  const [open, setOpen] = React.useState(true);

  const handleClose = () => {   
    setOpen(false);
    console.log("set Open is closed", open);
  };

  const handleExecute = () => {   
    setOpen(false);
    console.log("Calling Execute from dailogue box", open);
    props.execEnvChecked( true );
  };

  return (<Subscription subscription={HEALTH_CHECK_PROCESSING}>
    {({ data }) => {
       if (data && data.healthCheckProcessing.message) {
        return (
          <div>
            <Dialog
              open={open}
              onClose={handleClose}
              aria-labelledby="alert-dialog-title"
              aria-describedby="alert-dialog-description"
            >
              <DialogTitle id="alert-dialog-title"><span style={{color: 'red'}}>Server health check status</span></DialogTitle>
              <DialogContent>
                <DialogContentText id="alert-dialog-description">
                  {data.healthCheckProcessing.message}
                </DialogContentText>
              </DialogContent>
              <DialogActions>
                <Button onClick={handleClose} color="primary">
                  Abort
                  </Button>
                <Button onClick={handleExecute} color="primary" autoFocus>
                  Continue Execution
                  </Button>
              </DialogActions>
            </Dialog>
          </div>);
      }
      else {
        return null
      }
    }
    }
  </Subscription>
  )
}

export default SubscribeToHealthCheck;