import React, { Fragment } from 'react';
import NavBar from '../nav/Navbar';
import axios from 'axios';
import AuditGridComponent from './auditgridComponent';




export default class AuditComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            data: []
        }
    }
    componentDidMount() {
        const URL = `http://${process.env.REACT_APP_SERVER}:5000/fetchAuditLogs`;
        const data = {
            'sysId': '0a46af090f4a5e00c7334ebce1050e32'
        }
        axios.post(URL, data).then((res) => {
            console.log('---handleUpload---', res);
            if(res.data && res.data.length > 0){
                this.setState({
                    data: res.data
                })
            }else {
               const dummy =  [
                    {  'name':''},
                    {  'email':''},
                    {  'message':'' },
                    {  'revision':''  },
                    {  'repopath':''  },
                    {  'environment':''  },
                    {  'appname':''  },
                    {  'tags':'' }
                ]
                this.setState({
                    data: dummy
                })
            }
            

        })
    }
    

    render() {
        return (
            <Fragment>
                <NavBar stylename="prodlayout" />
                <div className="container" style={{ 'background': '#fff', 'marginTop': '20px', 'padding': '20px' }}>
                    <div className="tableContainer">
                        <AuditGridComponent data={this.state.data}/>
                        
                    </div>
                </div>
            </Fragment>
        )
    }
}