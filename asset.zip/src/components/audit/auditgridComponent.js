import React, {Fragment} from 'react';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import MaterialTable from 'material-table';

const columns = [
    { id: 'name', label: 'Name', },
    { id: 'email', label: 'Email' },
    { id: 'message', label: 'Message', width: '300px' },
    { id: 'revision', label: 'Revision' },
    { id: 'repopath', label: 'Repo path' },
    { id: 'environment', label: 'Environment' },
    { id: 'appname', label: 'Application Name' },
    { id: 'tags', label: 'Tags' }
]

export default class AuditGridComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            setRowsPerPage:10, setPage:0, page:0, rowsPerPage:10
        }
    }
   
    render() {
        console.log('this.props',this.props.data);
       const data = this.props.data
        return (
            <Fragment>
                <MaterialTable
                title="Audit Log Table"
                columns={[
                    { feild: 'name', title: 'Name' },
                    { feild: 'email', title: 'Email' },
                    { feild: 'message', title: 'Message', width: '300px' },
                    { feild: 'revision', title: 'Revision' },
                    { feild: 'repopath', title: 'Repo path' },
                    { feild: 'env', title: 'Environment' },
                    { feild: 'appname', title: 'Application Name' },
                    { feild: 'tags', title: 'Tags' }
                ]}
                data={data}        
                  options={{
                    sorting: true
                  }}
                  onRowClick= {(event)=> {
                        console.log(this)
                  }}
                />
                {/* 
                <Table stickyHeader aria-label="sticky table">
                    <TableHead>
                        <TableRow>
                            {columns.map((column) => (
                                <TableCell key={column.id} >
                                    <b>{column.label}</b>
                                </TableCell>
                            ))}
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {this.props.data.slice(this.state.page * this.state.rowsPerPage, this.state.page * this.state.rowsPerPage + this.state.rowsPerPage).map((row) => (
                            <TableRow key={row.name}>
                                <TableCell component="th" scope="row">{row.name}</TableCell>
                                <TableCell component="th" scope="row">{row.email}</TableCell>
                                <TableCell component="th" scope="row">{row.message}</TableCell>
                                <TableCell component="th" scope="row">{row.revision}</TableCell>
                                <TableCell component="th" scope="row">{row.repopath}</TableCell>
                                <TableCell component="th" scope="row">{row.env}</TableCell>
                                <TableCell component="th" scope="row">{row.appname}</TableCell>
                                <TableCell component="th" scope="row">{row.tags}</TableCell>
                            </TableRow>
                        ))}
                    </TableBody>

                </Table>
                <TablePagination
                    rowsPerPageOptions={[10, 25, 100]}
                    component="div"
                    count={this.props.data.length}
                    rowsPerPage={this.state.rowsPerPage}
                    page={this.state.page}
                    onChangePage={this.handleChangePage.bind(this)}
                    onChangeRowsPerPage={this.handleChangeRowsPerPage.bind(this)}
                /> */}
            </Fragment>)
    }
}
