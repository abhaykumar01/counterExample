import React, { Component, Fragment } from 'react';
import axios from 'axios';
import { withStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import NavBar from '../nav/Navbar';
import Button from '@material-ui/core/Button';
import Select from 'react-select';

const styles = theme => ({
    root: {
        flexGrow: 1,
    },
    paper: {
        marginTop: '14em',
        padding: theme.spacing(2),
        textAlign: 'center',
        color: theme.palette.text.secondary,
    },
});
class FileUpload extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedFile: '',
            loaded: 0,
            fileUrl: '',
            error: '',
            vaultType: "encrypt"

        }
    }


    handleUploadImage = (e) => {
        e.preventDefault();

        const data = new FormData();
        data.append('file', this.uploadInput.files[0]);
        data.append('filename', this.fileName.value);
        const url = `http://${process.env.REACT_APP_SERVER}:5000/upload`;
        console.log('---url ---')
        fetch(url, {
            method: 'POST',
            body: data,
        })
    }

    handleselectedFile = (e) => {
        this.setState({
            selectedFile: e.target.files[0],
            loaded: 0,
            error: ''
        })
    }

    handleUpload = () => {
        console.log('------handleUpload --------', this.state.selectedFile);
        if (this.state.selectedFile === '') {
            this.setState({
                error: 'Please select file'
            })
        } else {
            const data = new FormData();
            console.log(this.state.selectedFile.name)
            data.append('file', this.state.selectedFile, this.state.selectedFile.name);
            data.append('vaultType', this.state.vaultType);
            const url = `http://${process.env.REACT_APP_SERVER}:5000/upload`;

            axios.post(url, data, {
                onUploadProgress: ProgressEvent => {
                    this.setState({
                        loaded: (ProgressEvent.loaded / ProgressEvent.total * 100),
                    });
                },
            })
                .then(res => {
                    console.log('---handleUpload---', res);
                    this.setState({
                        fileUrl: `http://${process.env.REACT_APP_SERVER}:5000/${res.data.file}`,
                    })
                })
        }

    }
    handlevaultChange = (e) => {
        const value = e.value
        this.setState({
            type: value
        })
    }
    render() {
        const options = [
            { value: 'encrypt', label: 'Encrypt' },
            { value: 'decrypt', label: 'Decrypt' }]
        return <Fragment>
            <NavBar stylename="prodlayout" />
            <div className="container" style={{ 'background': '#fff', 'marginTop': '20px', 'padding': '20px' }}>

                <div className="row basemargin">
                    <Typography variant="h6" gutterBottom style={{ 'marginLeft': '13px' }}>Choose file to encrypt/decrypt</Typography>
                </div>
                <div className="row basemargin">
                    <div className="col-2" style={{ 'textAlign': 'right' }}> <label>File</label></div>
                    <div className="col-8">
                        <input type="file" name="fileupload" id="file_upload" onChange={this.handleselectedFile} />
                    </div>
                </div>
                <div className="row basemargin">
                    <div className="col-2" style={{ 'textAlign': 'right' }}> <label>Vault</label></div>
                    <div className="col-8">
                        <Select name="vault" multiple
                            onChange={optn => this.setState({'vaultType': optn.value })}
                            value={this.state.type}
                            options={options} />
                    </div>
                </div>
                <div className="row basemargin">
                    <div className="col-2"></div>
                    <div className="col-8">
                        <Button onClick={this.handleUpload} variant="contained" color="primary" style={{ 'marginTop': '15px' }}>Upload</Button>
                    </div>
                </div>
                <div className="row basemargin">
                    <div className="col-2"></div>
                    <div className="col-8">
                        {this.state.fileUrl !== '' ?
                            <div className="alert alert-success" ><strong>Success! </strong>File has been uploaded.
                        <a href={this.state.fileUrl} download target="_blank" style={{ 'float': 'right' }}>Download File</a></div> : null}
                        {this.state.error !== '' ?
                            <div className="alert alert-danger">{this.state.error}</div> : null}
                    </div>
                </div>
            </div>
        </Fragment>
    }
}

export default withStyles(styles)(FileUpload);
