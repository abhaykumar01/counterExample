import React, {Component} from 'react';
import StarNonProd from '../nonprod/StarNonProd';
import NavBar from '../nav/Navbar';

export default class NonProdLayout extends Component{

    render(){
        return (
        <div>
            <NavBar stylename="nonprodlayout"/>
           <StarNonProd />
        </div>)
    }
}