import React, {Component} from 'react';
import StarPage from '../star/StarPage';
import NavBar from '../nav/Navbar';
import Auth from '../../auth/Auth';

export default class ProdLayout extends Component{

    componentDidMount() {
        if(!Auth.isProdAccess()){
            this.props.history.push('/nonprod')
        }
    }

    render(){
        return (<div>
            <NavBar  stylename="prodlayout"/>
             <StarPage env='Production' />
        </div>)
    }
}