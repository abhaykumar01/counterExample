import React, { useState } from 'react';
import {changePassword} from '../../service/UserService';
import NavBar from '../nav/Navbar';

const ChangePassword = (props) => {
    const [password, setPassword] = useState({});
    const [isPasswordChangeSuccessful, setPasswordChange] = useState(true);

    const onChange = (e) => {
        setPassword({
            ...password,
            [e.target.name]: e.target.value
        })
    }

    const resetPassword = async () => {
        console.log('---reset password ---', password);
        const result = await changePassword({
            email: password.name,
            password: password.password
        })
        console.log('---result ---', result);
        if(result.error){
            setPasswordChange(false);
        }
        if(result.data.success){
            props.history.push('/login');
        }else {
            setPasswordChange(false);
        }
    }

    return (
        <div>
            <NavBar stylename="prodlayout" />
        
            <div className="container-fluid align-items-center">
                <div className="row mt-1">{!isPasswordChangeSuccessful? <div className="col-2 offset-4"><span className="badge badge-danger">Error in Changing Password</span></div>: <span></span>}</div>
                <div className="row mt-5">
                    <div className="col-2 offset-4">
                        <label htmlFor="name">Name</label>
                    </div>
                    <div className="col-4 ">
                        <input type="text" placeholder="Username" name="name" className="col-10" onChange={onChange} />
                    </div>
                </div>
                <div className="row mt-2">
                    <div className="col-2 offset-4">
                        <label htmlFor="password">New Password</label>
                    </div>
                    <div className="col-4 ">
                        <input type="password" placeholder="Enter New Password" name="password" className="col-10" onChange={onChange} />
                    </div>
                </div>
                <div className="row mt-2">
                    <div className="col-2 offset-4">
                        <label htmlFor="cnfrmpassword">Confirm Password</label>
                    </div>
                    <div className="col-4 ">
                        <input type="password" placeholder="Confirm Password" name="cnfrmpassword" className="col-10" onChange={onChange} />
                    </div>
                </div>
                <div className="row mt-2">
                    <div className="col-2 offset-4">
                        <button type="button" className="btn btn-primary" onClick={resetPassword}>Change Password</button>
                    </div>
                </div>

            </div>
        </div>
    )
}

export default ChangePassword;