import React, {useState, Fragment} from 'react';
import {authenticate} from '../../service/ServiceNow';
import { makeStyles } from '@material-ui/core/styles';
import CircularProgress from '@material-ui/core/CircularProgress';
import green from '@material-ui/core/colors/green';
import TextField from '@material-ui/core/TextField';
import FormControl from '@material-ui/core/FormControl';
import clsx from 'clsx';
import Auth from '../../auth/Auth';
import Typography from '@material-ui/core/Typography';
import NavBar from '../nav/Navbar';


const useStyles = makeStyles(theme => ({
 
    heading: {
      fontSize: theme.typography.pxToRem(15),
      flexBasis: '33.33%',
      flexShrink: 0,
      textAlign: 'center',
      color: 'red',
    },

    wrapper: {
      margin: theme.spacing(1),
      position: 'relative',
      textAlign: 'center'
    },

    buttonProgress: {
      color: green[500],
      position: 'absolute',
      top: '50%',
      left: '50%',
      marginTop: -12,
      marginLeft: -12,
    },
  }));

const Login =(props) => {
    const classes = useStyles();
    const [values, setValues] = useState({
        username: '',
        password: '',
    
        success: false,
        loading: false,
        result: '',
    })
    const loginclass = 'logincontainer';
    const handleChange = name => event => {

        setValues({ ...values, [name]: event.target.value});
    }
   const signin = async (event) => {
        event.preventDefault();
        if (values.username === "" || !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.username) || values.password === "" || values.password.length < 8) {
          setValues(
            {
              ...values, 
              result: 'The password must be at least 8 characters long. Please use a valid email address.',
              password: ''
            })
        }
        else
        {
          const response = await authenticate(values.username, values.password);
          console.log('----response in signin----',response);
          if( !response.error){
            const {token } = response.data;
            console.log('----token----',token);
            Auth.authenticationUser(token);
            if (Auth.isProdAccess()) {
              props.history.push('/prod');  
            } else {
              props.history.push('/nonprod');
            }
            
          }          
          else{
            console.log('----in else block ----', response.error.data);
            // if(response.error.data && response.error.data.invalidcredential){
            //   setValues(
            //     {
            //       ...values, 
            //       result:  response.error.data.invalidcredential,
            //       password: ''
            //     })
            // }else {
            //   setValues(
            //     {
            //       ...values, 
            //       result:  response.error,
            //       password: ''
            //     })
            // }
            setValues(
                  {
                    ...values, 
                    result:  response.error.data,
                    password: ''
                  })
       }
      }          
   }

   const forgotPassword = () => {
     props.history.push('/changepassword')
   }
 
    return(
      <Fragment>
        <form className={loginclass} noValidate autoComplete="off" onSubmit={signin}>
            <FormControl >
            <TextField
                    error={false}
                    id="username"
                    label="Username"
                    className="xyz"
                    value={values.username}
                    onChange={handleChange('username')}
                    margin="normal"     
                />
               </FormControl>
               <FormControl >
                <TextField
                        error={false}
                        id="password"
                        label="Password"
                        className="cde"
                        value={values.password}
                        type="password"
                        onChange={handleChange('password')}
                        margin="normal"     
                    />
               </FormControl>
               
                <div className={classes.wrapper}>
                  <input type="submit" value="Login" className="btn btn-primary btn-sm"
                      disabled={props.loading} />
                      {props.loading && <CircularProgress size={24} className={classes.buttonProgress} />}
                      {/* <button type="button"  className="btn btn-secondary btn-sm ml-2" onClick={forgotPassword}>Forgot Password</button> */}
                </div>
                <div className={classes.wrapper}>
                  {values.result? <div  className="alert alert-danger" ><strong>Warning!</strong> {values.result} </div> : null}
        </div>
        </form>
          
        </Fragment>
    )
    
}

export default Login;