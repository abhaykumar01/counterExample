import React, { Component, Fragment } from 'react';
import { NavLink as RouterLink } from 'react-router-dom';
import Auth from '../../auth/Auth';
import Grow from '@material-ui/core/Grow';
import Paper from '@material-ui/core/Paper';
import Popper from '@material-ui/core/Popper';
import ClickAwayListener from '@material-ui/core/ClickAwayListener';
import MenuItem from '@material-ui/core/MenuItem';
import MenuList from '@material-ui/core/MenuList';
import AccountCircleIcon from '@material-ui/icons/AccountCircle';


export default class NavBar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      open: false,
      setOpen: false
    }
    this.anchorRef = React.createRef();
  }

  handleClose = (event) => {
    if (this.anchorRef.current && this.anchorRef.current.contains(event.target)) {
      return;
    }
    this.setState({
      setOpen: false
    })
  }
  handleListKeyDown = (event) => {
    if (event.key === 'Tab') {
      event.preventDefault();
      this.setState({
        setOpen: false
      })
    }
  }
  handleToggle = () => {
    this.setState({
      setOpen: true
    })

  };
  render() {
    console.log('---isProdAccess -----', Auth.isProdAccess());
    return (
      <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
        <RouterLink className="navbar-brand flex-start mb-0 mr-4 h1" to="/">STAR</RouterLink>
        <ul className="navbar-nav mr-auto mt-lg-0">
          {Auth.isProdAccess() ?
            <li className="nav-item  mr-4">
              <RouterLink
                className="nav-link"

                to="/prod">
                Production
            </RouterLink>
            </li>
            : null
          }
          <li className="nav-item mr-4">
            <RouterLink
              className="nav-link"
              to="/nonprod">
              Non Production
            </RouterLink>

          </li>
          {Auth.isProdAccess() ?
            <Fragment>
              <li className="nav-item mr-4">
                <RouterLink
                  className="nav-link"


                  to="/fileupload">
                  File Upload
            </RouterLink>
              </li>
              <li className="nav-item mr-4">
                <RouterLink
                  className="nav-link"
                  to="/user">
                  Users
            </RouterLink>

              </li>
            </Fragment>
            : null}
            <li className="nav-item mr-4">
            <RouterLink
              className="nav-link"
              to="/audit">
              Audit
            </RouterLink>

          </li>
        </ul>
        <ul className="navbar-nav mr-auto my-nav1">
          {/*  <li className="nav-item mr-4">
            <RouterLink 
                  className="nav-link"
                  activeClassName="activeRoute"
                  
                  to={Auth.isUserAuthenticated() ? "/logout" : "/login"}>
              {Auth.isUserAuthenticated() ? "Logout" : "Login"}
            </RouterLink>
          </li> */}
          <li ref={this.anchorRef} aria-controls={this.state.open ? 'menu-list-grow' : undefined} aria-haspopup="true" className="nav-item logoutmenu" >
            <a className="nav-link" onClick={this.handleToggle.bind(this)}>
              <span style={{"color":"#007bff"}}>{Auth.isUserAuthenticated() ? Auth.getDecodedToken() : ""}</span>
              <AccountCircleIcon fontSize="large" /> 
            </a>
            <Popper open={this.state.setOpen} anchorEl={this.anchorRef.current} role={undefined} transition disablePortal>
              <Paper>
                <ClickAwayListener onClickAway={this.handleClose.bind(this)}>
                  <MenuList autoFocusItem={this.state.open} id="menu-list-grow" onKeyDown={this.handleListKeyDown.bind(this)}>
                    <MenuItem ><span className="profileUser">{Auth.isUserAuthenticated() ? Auth.getDecodedToken() : ""}</span></MenuItem>
                    <MenuItem><RouterLink to="/changepassword">Change Password</RouterLink> </MenuItem>
                    <MenuItem><RouterLink to={Auth.isUserAuthenticated() ? "/logout" : "/login"}> {Auth.isUserAuthenticated() ? "Logout" : "Login"} </RouterLink></MenuItem>
                  </MenuList>
                </ClickAwayListener>
              </Paper>

            </Popper>
          </li>
        </ul>
      </nav>
    )
  }
}