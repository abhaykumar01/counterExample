import React, { useState, Fragment, useReducer } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import CircularProgress from '@material-ui/core/CircularProgress';
import green from '@material-ui/core/colors/green';
import SubscribeToAnsibleTagResult from '../SubscribeToAnsibleTagResult';
import Select from 'react-select';
import { getEnvironmentsForApplication } from '../../service/UserService';
import Auth from '../../auth/Auth';
import { fetchAnsibleTags, svncheckout, executeAnsibleTasks } from '../../service/ServiceNow';
import QueryComponent from '../star/TCRQueryComponent';
import { TCRProcessingReducer, tcrProcessingMessages } from '../../reducers/tcrprocessing/TCRProcessingReducer';


const useStyles = makeStyles(theme => ({
  buttonProgress: {
    color: green[500],
    position: 'absolute',
    top: '50%',
    left: '50%',
    marginTop: -12,
    marginLeft: -12,
  },
}));
const actions = [
  { value: 'Deploy', label: 'Deploy' },
  { value: 'Rollback', label: 'Rollback' },
];

const srcsystems = [
  { value: 'SVN', label: 'Subversion' },
  { value: 'git', label: 'Bitbucket' },
];

const initialState = {
  srcsys: srcsystems[0].value,
  app: {},
  srcpath: '',
  srcrevision: '',
  disabled: false,
  selectivetags:false,
  currentsrcsys: srcsystems[0],
  tag: ['all'],
  environments: [],
  currentenvironment: {},
  showAnsibleTags: false,
  curtime: Date.now(),
  isExecuteButtonDisabled: false,
  isEnvChecked: false,
  loading: false,
  action: actions[0],
  tcrno: '',
  activateAnsibleTagResult: false,
  errors: {},
  disableSelectiveTags: true,
  activateSearchResult: false,
  svncheckouterror: {}
}

const SVNCheckOutForm = props => {
  const classes = useStyles();
  const [values, setValues] = useState({ ...initialState });
  const [state, dispatch] = useReducer(TCRProcessingReducer, tcrProcessingMessages);

  const handleChange = event => {

    // console.log('--- value : -', event.target.value);
    const errors = validateFields();
    if (event.target.name ==='srcpath') {
      delete errors.srcpath;
    } 
    if(event.target.name ==='srcrevision'){
      delete errors.srcrevision;
    }
    let disable = false;
    console.log('---errors ----',errors);
    if(event.target.value === '' || Object.keys(errors).length > 0){
      disable = true;
      setValues(
        { ...values, 
        [event.target.name]: event.target.value,
        disableSelectiveTags: disable,
        activateSearchResult: false,
        errors: errors
      });
    }else {
     
      // delete errors.[event.target.name];

      setValues(
        { ...values, 
        [event.target.name]: event.target.value,
        disableSelectiveTags: disable,
        activateSearchResult: true,
        errors: errors
      });
    }
  
  };

  const handleAppChange = async (event) => {
    console.log('...handleAppChange...', event);
    const envs = await getEnvironmentsForApplication(event.value);
   const env = envs && envs.data.length > 0 ? envs.data[0]: '';
    console.log('----envs----', envs);
    const errors = validateFields();
    delete errors.applications;
    delete errors.environments;
    setValues(
      {
        ...values,
        app: event,
         environments: envs.data,
         currentenvironment: env,
        tcrno: Auth.getUserSysId() + '_' + event.value + '_' + env.value,
        disableSelectiveTags: Object.keys(errors).length>0,
        errors: errors
      });
  };

  const handleRepoType = event => {
    console.log('...handleRepoType...', event);
    const errors = validateFields();
    setValues(
      { ...values, 
        srcsys: event.value, 
        currentsrcsys: event,
        disableSelectiveTags: Object.keys(errors).length>0 
      });
  };

  const handleReset = () => {
    console.log("---reset button --- pressed");
    setValues(initialState);
    dispatch({type: 'cleanup'});
  }

  const validateFields = () => {
    let errors = {};
    console.log('---values.app ---',values.srcpath);
    if( Object.keys(values.app).length  === 0){
      errors.applications = 'Application Should not be empty'
    }
    if(Object.keys(values.currentenvironment).length === 0){
      errors.environments= 'Environment Should not be empty';
    }
    if(values.srcpath === undefined || values.srcpath === ''){
      errors.srcpath = 'Repository Path Should not be empty'
    }
    if(values.srcrevision === undefined || values.srcrevision === ''){
      errors.srcrevision = 'Revision No Should not be empty'
    }
    return errors;
  }
  const selectiveTags =async (e)  => {
    console.log('---e ---', e.target.checked);
 
      if(!e.target.checked){
        dispatch({type: 'cleanup'});
        setValues(
          {
            ...values,
            disabled: false, 
            errors: {}, 
            selectivetags: e.target.checked,
            activateAnsibleTagResult: e.target.checked,
            activateSearchResult: false
          });
      }
      
   
    if(e.target.checked){
      const errors = validateFields();
      if(Object.keys(errors).length > 0){
        setValues({...values, errors: errors, selectivetags: e.target.checked})
      } else{
        setValues(
          {
            ...values,
            disabled: true, 
            selectivetags: e.target.checked, 
            activateAnsibleTagResult: e.target.checked,
            activateSearchResult: true
          });
        await  fetchTags(e);
      } 
    }
  }

  const fetchTags = async (event) => {
    console.log("--- Current values----", values);
    
    const repo = { sys: values.srcsys, repo: values.srcpath, version: values.srcrevision }
    const responses = [];
    const records = [];

    const result = await svncheckout(repo, values.tcrno, values.currentenvironment.value, values.action.value, responses, values.curtime, records);
    console.log('---result -----', result);
    
    const tags = await fetchAnsibleTags(values.app, values.tcrno, values.curtime, values.action.value, values.srcsys, values.currentenvironment.value);
    console.log('----tags ----', tags);
    if (!tags.error) {
      setValues({
        ...values,
        activateAnsibleTagResult: true,
        activateSearchResult: true,
        selectivetags: true, 
        success: true,
        disabled: true,
      })
    } else {
      setValues({
        ...values,
        success: false,
        disabled: false,
        activateAnsibleTagResult:true,
        selectivetags: true 
      })
    }
    console.log("---Tags received SVNCheckoutForm.js---", tags);
  }

  const handleEnvChange = (env) => {
    console.log('----env----', env);
    const errors = validateFields();
    setValues(
      { 
        ...values, 
        currentenvironment: env , 
        tcrno: Auth.getUserSysId() + '_' + values.app.value + '_' + env.value,
        disableSelectiveTags: Object.keys(errors).length>0
      });
  }

  const updateAnsibleTags = async (tags) => {
    console.log('---updateAnsibleTags ---', tags);
    setValues({
      ...values,
      tag: tags,
    })
  }

  const handleActionsChange = (data) => {
    const errors = validateFields();
    setValues({
      ...values,
      action: data,
      disableSelectiveTags: Object.keys(errors).length>0
    })
  }

  

  

  const executeTask = async (event) => {
    console.log('-----Going to execute Ansible Task --------', values.tags, values.action);
   //1. Validate the field and if if it is not valid then skip processing
   const errors  = validateFields();
     if(Object.keys(errors).length > 0){
      setValues({...values, errors: errors})
     }else {
      setValues({
        ...values,
        loading: true,
        activateSearchResult: false
      })
      dispatch({type: 'cleanup'});
      setTimeout(async ()=> {
        setValues({
          ...values,
          loading: true,
          activateSearchResult: true
        });
       await executeSubmitTask();
      },1000);  
     }

    
   
  }

  const executeSubmitTask = async () => {
    const responses = [];
    const records = [];

    const repo = { sys: values.srcsys, repo: values.srcpath, version: values.srcrevision };
    const svncheckoutresult = await svncheckout(repo, values.tcrno, values.currentenvironment.value, values.action, responses, values.curtime, records, values.app.value);
    console.log('---svncheckoutresult -----', svncheckoutresult);

    if(svncheckoutresult.error){

    }else {
      const result = await executeAnsibleTasks(
        values.srcsys,
        values.srcpath,
        values.tcrno,
        values.action.value|| 'Deploy',
        values.currentenvironment.value,
        values.curtime,
        values.tag,
        values.app.value,
        values.isEnvChecked,
        values.srcrevision)
        ;
  
      console.log('---result ---', result);
    }
    
    setValues({
      ...values,
      loading: false,
      activateSearchResult: true
    })
  }

  const getEnvironmentValue = (env) => {
    if (env && env.value) {
      return env.value;
    }
    else return '';
  }

  const getErrorsDiv = () => {
    if(values.errors && Object.keys(values.errors).length > 0){
      return (
        <div className="row mt-4">
        {Object.keys(values.errors).map((error,i)=> <div className="alert alert-danger ml-1" key={i}>{values.errors[error]}</div>)}
      </div>
      )
    }else return null;
  }

  return (
    <Fragment>
      {console.log('--values---', values)}
      {getErrorsDiv()}
      
      <div className="row mt-4">

        <div className="col-10 col-md-3">
          <label className="col-form-label" htmlFor="applications">Application</label>
        </div>
        <div className="col-10 col-md-4">
          <Select name="applications"
            options={props.applications}
            onChange={handleAppChange}
            isDisabled={values.disabled}
            value={[values.app]} />
        </div>
        <div className="col-10 col-md-2">
          <label className="col-form-label" htmlFor="environments">Environment</label>
        </div>
        <div className="col-10 col-md-3">
          <Select name="environments"
            options={values.environments}
            onChange={handleEnvChange}
            value={[values.currentenvironment]}
            isDisabled={values.disabled} />
        </div>

      </div>
      <div className="row mt-1">
        <div className="col-10 col-md-3">
          <label className="col-form-label" htmlFor="sourcerepository">Repository Type</label>
        </div>
        <div className="col-10 col-md-2">
          <Select name="srcsys"
            options={srcsystems}
            onChange={handleRepoType}
            value={[values.currentsrcsys]}
            isDisabled={values.disabled}
          />
        </div>
      </div>
      <div className="row mt-1">
        <div className="col-10 col-md-3">
          <label className="col-form-label" htmlFor="srcpath">Repository Path</label>
        </div>
        <div className="col-10 col-md-4">
          <input className="col-12 form-control"
            type="text" name="srcpath"
            placeholder=""
            onChange={handleChange}
            value={values.srcpath}
            disabled={values.disabled} />
        </div>
        <div className="col-10 col-md-2">
          <label className="form-check-label" htmlFor="srcrevision">Revision No:</label>
        </div>
        <div className="col-10 col-md-3">

          <input className="col-12 form-control"
            type="text" name="srcrevision"
            placeholder=""
            onChange={handleChange}
            value={values.srcrevision}
            disabled={values.disabled} />
        </div>
      </div>
      <div className="row mt-1">
      <div className="col-10 col-md-3">
          <label className="col-form-label" htmlFor="actions">Actions</label>
        </div>
        <div className="col-10 col-md-2">
          <Select name="actions"
            options={actions}
            onChange={handleActionsChange}
            value={[values.action]}
            isDisabled={values.disabled}
          />
        </div>
        <div className="col-5 col-md-2 align-self-end form-check">
          <input className="form-check-input" type="checkbox"
                 disabled={values.disableSelectiveTags}
                 name="selectivetags" onChange={selectiveTags} 
                 checked={values.selectivetags} />
          <label htmlFor="selectivetags" className="col-10 form-check-label">Selective Tags</label>
        </div>
        <div className="col-3 col-md-1 ml-1 btn-group">
        <button type="button"
            className="btn btn-secondary" onClick={handleReset}>Reset</button>
        </div>
      </div>
      <div className="mt-2">
        {values.activateAnsibleTagResult? 
        <SubscribeToAnsibleTagResult
          tcrno={values.tcrno}
          curtime={values.curtime}
          action='Deploy'
          environment={getEnvironmentValue(values.currentenvironment)}
          svnrepo={values.srcpath}
          srcsys={values.srcsys}
          svnrevision={values.srcrevision}
          updateAnsibleTags={updateAnsibleTags}
        />: null}
      </div>
    
      <div className="row mt-2">

        <div className="col-3 col-md-3 offset-md-4">
          <button
            className="btn starbutton"
            disabled={values.isExecuteButtonDisabled} onClick={executeTask} >Execute Task</button>
          {values.loading && <CircularProgress size={44} className={classes.buttonProgress} />}
        </div>

      </div>
      <hr />
      <div className="row mt-2">
        <QueryComponent activateAnsibleTagResult={values.activateSearchResult} 
                        tcr={{number: values.tcrno}}
                        env ={values.currentenvironment.value}
                        action= {values.action.value} />
      </div>

    </Fragment>
  )

}

export default SVNCheckOutForm;
