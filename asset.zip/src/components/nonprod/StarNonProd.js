import React, { Component } from 'react';
import SVNCheckOutForm from './SVNCheckOutForm';
import { svncheckout, getApplications } from '../../service/ServiceNow';
import Auth from '../../auth/Auth';

class StartNonProd extends Component {

  state = {
    success: false,
    loading: false,
    svnpath: '',
    svnrevision: '',
    result: {}
  }

  handleAppChange = (app) => {
    this.setState({
      app: app
    })
  }
  svnFormSubmit = async (svnpath, svnrevision) => {
    if (!this.state.loading) {
      this.setState({
        success: false,
        loading: true,
      })
    }
    const result = await svncheckout(svnpath, svnrevision);
    console.log('----result in StarNonProd-----', result);

    if (!result.error) {
      this.setState({
        success: true,
        loading: false,
        result: result.data
      })
    } else {
      this.setState({
        success: false,
        loading: false,
        result: result.error
      })
    }
  }
  async componentDidMount() {
    const applications = await getApplications(Auth.getUserSysId());

    this.setState({
      applications: applications.data
    })
  }

  render() {
    return (
      <div className="container">

        <SVNCheckOutForm
          applications={this.state.applications}
         
          svnFormSubmit={this.svnFormSubmit}
          loading={this.state.loading}
          success={this.state.success}
          env={this.props.env} />
      </div>
    )
  }
}

export default StartNonProd;
