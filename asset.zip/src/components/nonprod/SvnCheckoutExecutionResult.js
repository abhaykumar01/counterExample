import React from 'react';
import gql from 'graphql-tag';
import { Subscription } from 'react-apollo';
import ExecutionState from '../snackbar/SnackBarComponent';

const CHECKOUT_PROCESSING_SUBSCRIPTION = gql`

  subscription onCheckoutProcessing {
      checkoutProcessing{
        message
        error
        repopath
        reporevision
        tcrno
      }     
  }
` 

const SvnCheckoutExecutionResult = (props) =>{
    console.log('---props---',props);
    return (<Subscription subscription={CHECKOUT_PROCESSING_SUBSCRIPTION}>
        {({data , loading}) => {
            if(loading) return "";
            console.log('----data----',data);
            if(data.checkoutProcessing && props.repopath && props.reporevision){
                const d = data.checkoutProcessing;
                console.log('---d------',d);
                let messages = [d];
                return <ExecutionState executions={messages} />
             }
            else{
                return <p>Loading...</p>
            }
        }
        }
    </Subscription>

) }

export default SvnCheckoutExecutionResult;
