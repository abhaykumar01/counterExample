import React, {useReducer,useEffect} from 'react';
import gql from 'graphql-tag';
import PropTypes from 'prop-types';
import { makeStyles } from '@material-ui/core/styles';
import {TCRProcessingReducer, tcrProcessingMessages} from '../../reducers/tcrprocessing/TCRProcessingReducer';

const TCR_PROCESSING_SUBSCRIPTION = gql`

  subscription onTcrProcessing {
      tcrProcessing {
        message
        error
        tcrno
      }     
  }
` 

const StarExecutionResult = (props) =>{
   const [state, dispatch] = useReducer(TCRProcessingReducer, tcrProcessingMessages);
 
  useEffect(() => {
    props.subscribeToMore({
      document: TCR_PROCESSING_SUBSCRIPTION,
      updateQuery: (prev, {subscriptionData}) => {
        console.log('----prev ----',prev);
        console.log('----subscriptionData ----',subscriptionData);
        if(!subscriptionData.data) return prev;
        console.log('---subscriptionData ---',subscriptionData);
        if(subscriptionData.data.tcrProcessing.tcrno === props.tcr.number){
          let msg = subscriptionData.data.tcrProcessing;
          console.log('---msg ----',msg);
          dispatch({type: 'tcrProcessing', payload: msg})
        }
      }
    })
  }, [])

  return (
    <ExecutionState executions = {state} />
  ) 
}

export default StarExecutionResult;

   const MySnackbarContentWrapper = (props) =>{

    const { className, message, onClose, variant,seq, ...other } = props;
    let cssClass = `alert alert-${variant}`;
    return (
      <div className={cssClass}>
        <span className="badge badge-pill badge-info">{seq}.</span><code>{message}</code>
      </div>

    );
  }
  
  MySnackbarContentWrapper.propTypes = {
    className: PropTypes.string,
    message: PropTypes.node,
    onClose: PropTypes.func,
    variant: PropTypes.oneOf(['success', 'warning', 'error', 'danger','info']).isRequired,
  };

  
  const useStyles2 = makeStyles(theme => ({
    margin: {
      margin: theme.spacing(1),
    },
  }));

export const ExecutionState = props => {

    const classes = useStyles2();
    console.log('----executions ----',props.executions);

    const getVariant = (msg) => {
      if(msg.error && msg.error.length > 0) return {variant: "danger",seq: msg.seq, message: msg.error[0]};

      if(msg.message.includes('ORA')){
        console.log('----msg includes ORA----', msg.message);
        return {variant: "warning", seq: msg.seq, message: msg.message};
      }
      return {variant: "success",seq: msg.seq, message: msg.message};
    }

    return   props.executions.length > 0 && props.executions.map((e,i) => {
        const msg = getVariant(e);
      return <MySnackbarContentWrapper key={i} variant={msg.variant}  
      className={classes.margin} 
      message={msg.message}
      seq={msg.seq}  />
      }
     );
}
