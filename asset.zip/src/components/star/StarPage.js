import React, { Component } from 'react';
import StarSearchForm from './StarSearchForm';
import StarSearchResult from './StarSearchResult';
import {  getApplications, fetchAnsibleTags, getTCRData } from '../../service/ServiceNow';
import StarSearchUserMapping from './StarSearchUserMapping';
import Auth from '../../auth/Auth';
import QueryComponent from './TCRQueryComponent';


class StarPage extends Component {

  state = {
    success: false,
    loading: false,
    result: {},
    tohide: true,
    applications: [],
    app: '',
    showResult: false,
    showStarSearchResult: false,
    activateAnsibleTagResult:false,
    tcrno: '',
    showTCRValidationMessage: false,
    tcrValidationMessage: '',
    fetchTagError : ''

  }
  handleAppChange = (app) => {
    this.setState({
      tohide: false,
      app: app,
      showStarSearchResult: false
    })
  }

  processTCRFormSubmission =  async (tcrform) => {
    if (!this.state.loading) {
      this.setState({
        success: false,
        loading: true,
        activateAnsibleTagResult:true,
        tcrno: tcrform.tcrno
      })
    }
    const result = await getTCRData(tcrform.tcrno, tcrform.env, tcrform.action, this.state.app);
    console.log('----result in starpage-----', result);

    if (!result.error) {
      this.setState({
        success: true,
        loading: false,
        result: result.data,
        showResult: true,
        showStarSearchResult: true,
        activateAnsibleTagResult: true,
        tcrno: tcrform.tcrno,
        showTCRValidationMessage: false
      })
    } else {
      this.setState({
        success: false,
        loading: false,
        result: result.error.data,
        showStarSearchResult: true,
        activateAnsibleTagResult: true,
        showTCRValidationMessage: false
      })
    }
  }

  validateTCR = async (tcrform) => {
    this.setState({
      ...this.state,
      showStarSearchResult: false,
      activateAnsibleTagResult: false,
      showTCRValidationMessage: false
    })
    setTimeout(() => {
      this.processTCRFormSubmission(tcrform);
    },1000);

  }

  processAnsibleTagsResult = async (action) => {
    const system = this.state.result.repository.sys;
    const curtime = this.state.result.curtime;
    const tcrNo = this.state.result.tcr.number;
    this.setState({
      activateAnsibleTagResult: true
    })

    const tags = await fetchAnsibleTags(this.state.app, tcrNo, curtime, action,system,'Production');
    console.log('-------tags in porcessAnsibleTagsResult ----', tags);
    if (!tags.error) {
      this.setState({
        success: true,
        loading: false,
        tags: tags.data,
        showResult: true,
        fetchTagError: ''
      })

    } else {
      this.setState({
        success: false,
        loading: false,
        tags: tags.error.data,
        fetchTagError: tags.error.data
      })
    }
    console.log("---Tags received StarPage.js---", this.state.tags);
  }

  handleActionChange = async (action) => {
    if (!this.state.loading) {
      this.setState({
        success: false,
        loading: true,
        activateAnsibleTagResult: false,
      })
    }else {
      this.setState({
        activateAnsibleTagResult: false
      })
    }
    setTimeout(() => {
     this.processAnsibleTagsResult(action)
    }, 1000)
    
  }

  async componentDidMount() {
    const applications = await getApplications(Auth.getUserSysId());
    this.setState({
      applications: applications.data
    })
  }

  render() {
    console.log('---this.state ----',this.state);
    return (
      <div className="container mt-3">
       {this.state.fetchTagError !==''? <div className="alert alert-danger">{this.state.fetchTagError}</div>: null}
        <div className="row"  style={{borderBottom: '1px solid lightgrey'}}>
          <div className="col-md-7">

            <StarSearchUserMapping
              applications={this.state.applications}
              handleAppChange={this.handleAppChange}
              tcrFormSubmit={this.validateTCR}
              loading={this.state.loading}
              success={this.state.success}
              env={this.props.env} />

            {this.state.showResult ?

              <StarSearchForm handleActionChange={this.handleActionChange}
                loading={this.state.loading}
                success={this.state.success}
                result={this.state.result} 
                app={this.state.app}
                fetchTagError={this.state.fetchTagError}
               />

              : null}
          </div>
          <div className="col-md-5">
            {this.state.showStarSearchResult ? <StarSearchResult result={this.state.result} />
              :null}
          </div>
        </div>
        {this.state.showTCRValidationMessage? <div className="row"  style={{border: '1px solid red'}}>
        <div className="danger">
        {this.state.tcrValidationMessage}
      </div>
          </div>: null}
        
        <div className="row offset-2">
        <QueryComponent activateAnsibleTagResult={this.state.activateAnsibleTagResult} 
                        tcr={{number: this.state.tcrno}}
                        env ={this.props.env}
                        action= {''} />
        </div>
      </div>
    )
  }
}

export default StarPage;
