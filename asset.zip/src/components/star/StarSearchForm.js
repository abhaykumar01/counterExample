import React, { useState, Fragment, useReducer } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import CircularProgress from '@material-ui/core/CircularProgress';
import green from '@material-ui/core/colors/green';
import SubscribeToAnsibleTagResult from '../SubscribeToAnsibleTagResult';
import SubscribeToHealthCheck from '../SubscribeToHealthCheck';
import Select from 'react-select';
import { executeAnsibleTasks } from '../../service/ServiceNow';
import { TCRProcessingReducer, tcrProcessingMessages } from '../../reducers/tcrprocessing/TCRProcessingReducer';

const useStyles = makeStyles(theme => ({

  buttonProgress: {
    color: green[500],
    position: 'absolute',
    top: '50%',
    left: '50%',
    marginTop: -12,
    marginLeft: -12,
  },
}));

const actions = [
  { value: 'Deploy', label: 'Deploy' },
  { value: 'Rollback', label: 'Rollback' },
];

const StarSearchForm = props => {
  const classes = useStyles();
  const [state, dispatch] = useReducer(TCRProcessingReducer, tcrProcessingMessages);
  const [values, setValues] = useState({
    tcrno: '',
    age: '',
    multiline: 'Controlled',
    env: '',
    action: actions[0],
    errors: [{}],
    tag: [],
    svnpath: '',
    svnrevision: '',
    loading: false,
    tags: ['all'],
    showAnsibleTags: false ,
    isEnvChecked: false ,
    executeDisabled: false
  });


  const handleChange = event => {
    console.log('...name ACTION DISPLAY', event);
    setValues({ ...values, action: event });
    // props.handleActionChange( event.target.value );
  };

  const delay = async () => {
    setTimeout(1000);
  }

  const selectiveTags =async (e)  => {
    const checked = e.target.checked;
    const name = e.target.name;

    dispatch({type: 'cleanup'});
    console.log('---Going to call delay---');
    setTimeout( () => {
      setValues({
        ...values,
        [name]: checked,
        loading: checked,
        showAnsibleTags: checked
      })
      
      props.handleActionChange(values.action.value);
    },1000)
  }

  const updateAnsibleTags = (tags) => {
    setValues({
      ...values,
      tags: tags,
      loading: tags.length > 0 ? false : values.selectivetags
    })
  }

  const execEnvChecked = async (isChecked) => {
    setValues({ ...values, isEnvChecked: isChecked });
    await executeTask ();
  }

  const executeTask = async () => {
    console.log('---- StarSearchForm.js executeTask() --------', values.tags, values.action);
     setValues({...values, executeDisabled: true });
    const result = await executeAnsibleTasks(
      props.result.repository.sys,
      props.result.repository.repo,
      props.result.tcr.number,
      values.action.value,
      'Production',
      props.result.curtime,
      values.tags,
      props.app, 
      values.isEnvChecked,
      props.result.repository.version);
      if(result.error){
        setValues({
          ...values,
          executeDisabled: false
        })
      }
  }

  return (
    <Fragment>

      <div className="row">
        <div className="col-3">
          <label htmlFor="actions">Actions</label>
        </div>
        <div className="col-4">
          <Select name="actions" options={actions} onChange={handleChange}
            value={[values.action]}
          />
        </div>

        <div className="col-5 align-self-end form-check">
          <input className="form-check-input" type="checkbox" name="selectivetags" onChange={selectiveTags} />
          <label htmlFor="selectivetags" className="col-10 form-check-label">Selective Tags</label>
        </div>

      </div>
       {values.showAnsibleTags? 
      <SubscribeToAnsibleTagResult
        tcrno={props.result.tcr.number}
        curtime={props.result.curtime}
        action={values.action}
        environment='PROD'
        repo={props.result.repository.repo}
        srcsys={props.result.repository.sys}
        revision={props.result.repository.version}
        updateAnsibleTags={updateAnsibleTags}
      />: null }

      <SubscribeToHealthCheck
        execEnvChecked={execEnvChecked}
      />

      <div className="row mt-1">
        <hr />
        <div className="col offset-4">
          <button
            className="btn starbutton"
            disabled={values.executeDisabled} onClick={executeTask} >Execute Task</button>
          {props.loading && <CircularProgress size={24} className={classes.buttonProgress} />}
        </div>

      </div>

    </Fragment>
  )

}

export default StarSearchForm;
