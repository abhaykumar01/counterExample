import React from 'react';
import _ from 'underscore';
import { makeStyles } from '@material-ui/core/styles';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import Typography from '@material-ui/core/Typography';


const useStyles = makeStyles(theme => ({
    root: {
      width: '90%',
     
      backgroundColor: theme.palette.background.paper,
    },
    heading: {
        fontSize: theme.typography.pxToRem(15),
        flexBasis: '33.33%',
        flexShrink: 0,
      },
      secondaryHeading: {
        fontSize: theme.typography.pxToRem(15),
        color: theme.palette.text.secondary,
      },
  }));
  

const StarSearchResult = ({result}) => {
    const classes = useStyles();
    console.log('---result ---', result);
   
    return (
	   <div style={{ width: 'fit-content',borderLeft: '1px solid lightgrey'}}>
           {result.error && result.error !== ''? <div className="ml-2 row alert alert-danger">{result.error}</div>:
           <List className={classes.root}>
            <ListItem>
                <Typography className={classes.heading}>MCR No</Typography>
                <Typography className={classes.secondaryHeading}>{result.mcr? result.mcr.number: ''}</Typography>
            </ListItem>
            
            <ListItem>
                <Typography className={classes.heading}>MCR Status</Typography>
                <Typography className={classes.secondaryHeading}>{result.mcr? result.mcr.state: ''}</Typography>
            </ListItem>
            
            <ListItem>
                <Typography className={classes.heading}>TCR Status</Typography>
                <Typography className={classes.secondaryHeading}>{result.tcr? result.tcr.state: ''}</Typography>
            </ListItem>
           
	    <ListItem>
                <Typography className={classes.heading}>TCR Start_Date</Typography>
                <Typography className={classes.secondaryHeading}>{result.start_date? result.start_date: ''}</Typography>
            </ListItem>
	   
            <ListItem>
                <Typography className={classes.heading}>TCR End_Date</Typography>
                <Typography className={classes.secondaryHeading}>{result.end_date? result.end_date: ''}</Typography>
            </ListItem>
 
            <ListItem>
                <Typography className={classes.heading}>Assignee Group</Typography>
                <Typography className={classes.secondaryHeading}>{result.assignment_team? result.assignment_team.name: ''}</Typography>
            </ListItem>
            
            <ListItem>
                <Typography className={classes.heading}>Affected Service </Typography>
                <Typography className={classes.secondaryHeading}>{result.affected_service? result.affected_service.name: ''}</Typography>
            </ListItem>
            
            <ListItem>
                <Typography className={classes.heading}>Raiser Name</Typography>
                <Typography className={classes.secondaryHeading}>{result.change_raiser? result.change_raiser.u_full_name: ''}</Typography>
            </ListItem>
            
            <ListItem>
                <Typography className={classes.heading}>Assignee</Typography>
                <Typography className={classes.secondaryHeading}>{result.assignee_info? result.assignee_info.u_full_name: ''}</Typography>
            </ListItem>
            
            <ListItem>
                <Typography className={classes.heading}>Source Code </Typography>
                <Typography className={classes.secondaryHeading}>{result.repository? result.repository.sys: ''}</Typography>       
            </ListItem>

            <ListItem>
                <Typography className={classes.heading}>Repository Path</Typography>
               <Typography className={classes.secondaryHeading}>{result.repository? result.repository.repo: ''}</Typography>           
            </ListItem>
            <ListItem>
                <Typography className={classes.heading}>Repository Revision</Typography>
                <Typography className={classes.secondaryHeading}>{result.repository? result.repository.version: ''}</Typography>
            </ListItem>

            <ListItem>
                <Typography className={classes.heading}>Additional Notifier</Typography>
                <Typography className={classes.secondaryHeading}>{result.emails}</Typography>
            </ListItem>

          </List>
           }
        </div>
        
    )
}

export default StarSearchResult;
