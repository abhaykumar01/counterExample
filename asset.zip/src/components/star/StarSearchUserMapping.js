import React, { useState, useReducer } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import CircularProgress from '@material-ui/core/CircularProgress';
import green from '@material-ui/core/colors/green';
//import MenuItem from '@material-ui/core/MenuItem';

//import TextField from '@material-ui/core/TextField';
import Select from 'react-select';
import { TCRProcessingReducer, tcrProcessingMessages } from '../../reducers/tcrprocessing/TCRProcessingReducer';

const useStyles = makeStyles(theme => ({
  container: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  textField: {
    marginLeft: theme.spacing(5),
    marginRight: theme.spacing(1),
    width: '90%'
  },
  dense: {
    marginTop: 16,
  },
  menu: {
    width: 400,
  },
  wrapper: {
    margin: theme.spacing(1),
    position: 'relative',
  },
  buttonSuccess: {
    backgroundColor: green[500],
    '&:hover': {
      backgroundColor: green[700],
    },
  },
  fabProgress: {
    color: green[500],
    position: 'absolute',
    top: -6,
    left: -6,
    zIndex: 1,
  },
  buttonProgress: {
    color: green[500],
    position: 'absolute',
    top: '50%',
    left: '50%',
    marginTop: -12,
    marginLeft: -12,
  },
}));


const StarSearchUserMapping = props => {
  const classes = useStyles();

  const [values, setValues] = useState({
    tcrno: '',
    app: '',
    env: props.env || ''
  });
  const [state, dispatch] = useReducer(TCRProcessingReducer, tcrProcessingMessages);



  const handleChange = event => {
    setValues({ ...values, app: event.value ,result: false});
    props.handleAppChange(event.value);
  };

  const handleTCRChange = event => {
    setValues({ ...values, tcrno: event.target.value ,result: false })
  
  }

  const handleSubmit = () => {
    dispatch({type: 'cleanup'});

    if(!values.app){
      setValues({...values, result: "Please select appropriate Application."})
    }else if(! /^(tcr|TCR)\d{7}$/.test(values.tcrno)){
      setValues({...values, result: "Please provide valid TCR number"})
    }
    else {
      const tcrform = {
        tcrno: values.tcrno,
        action: values.action,
        env: values.env
      }
      props.tcrFormSubmit(tcrform);
    }
  }
  return (
    <>
      <div className="row">

        <div className="col-3">
          <label className="col-form-label" htmlFor="applications">Application</label>
        </div>
        <div className="col-9">
          <Select name="applications" options={props.applications} onChange={handleChange} />
        </div>

      </div>


      <div className="row mt-1">
        <div className="col-3">
          <label htmlFor="tcrno" className="col-form-label">TCR</label>
        </div>
        <div className="col-5">
          <input className="col-11 form-control" type="text" value={values.tcrno}
            name="tcrno"
            onChange={handleTCRChange} />
        </div>
        <div className="col-4">
          <button
            className="btn starbutton"
            disabled={props.loading} onClick={handleSubmit}>Validate TCR</button>
          {props.loading && <CircularProgress size={24} className={classes.buttonProgress} />}
        </div>
        <div >
         {values.result? <div  className="alert alert-danger" ><strong>Warning!</strong> {values.result} </div> : null}
        </div>
      </div>


      <div className="row">
        <hr />
      </div>


    </>

  )
}

export default StarSearchUserMapping;