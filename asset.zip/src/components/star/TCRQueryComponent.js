import React from 'react';
import gql from 'graphql-tag';
import {Query} from 'react-apollo';
import StarExecutionResult from './StarExecutionResult';

const TCR_QUERY = gql`

  query tcrQuery($tcrno: String!, $env: String, $action: String) {
      tcrQuery (tcrno: $tcrno, env: $env, action: $action){
        message
        error
        tcrno
      }     
  }
` 

const QueryComponent = props => {
    console.log('-QueryComponent--props ---',props);
    return (
      props.activateAnsibleTagResult?  <Query query={TCR_QUERY}
      variables={{
        tcrno: props.tcr.number,
        env: props.env,
        action: props.action
      }}>
        {({data, error, loading, subscribeToMore}) => {
          if(loading) return null;
          if(error) return <div>Error fetching Execution Result ----</div>
           console.log('----data in Query ----',data);
          return <StarExecutionResult subscribeToMore={subscribeToMore}
          tcr={props.tcr} data ={{tcrProcessing: {...data.tcrQuery}}} />
        }
  
        }
      </Query>: null
    )
  }

export default QueryComponent;