import React, { useReducer, useEffect, Fragment } from 'react';
import { UserReducer, userInitialState, UserCreationReducer } from '../../reducers/user/UserReducer';
import { ApplicationReducer } from '../../reducers/application/ApplicationReducer';
import { addNewUser, getAllApplications } from '../../service/UserService';
import Select from 'react-select';
import Auth from '../../auth/Auth';
import NavBar from '../nav/Navbar';
import Typography from '@material-ui/core/Typography';

const UserPage = (props) => {
    const [state, dispatch] = useReducer(UserReducer, userInitialState);
    const [state1, dispatch1] = useReducer(ApplicationReducer, []);
    const [state2, dispatch2] = useReducer(UserCreationReducer, {});

    useEffect(() => {
        if (!Auth.isProdAccess()) {
            props.history.push('/nonprod');
        }
        dispatch1({ type: 'LOADING' });
        const apps = async () => {
            const result = await getAllApplications();
            dispatch1({ type: 'LOADED', payload: result.data })
        }
        apps();

    }, [])

    const onChange = (e) => {
        dispatch({ type: 'input', payload: e.target })
    }

    const onChangeInput = (e) => {
        dispatch({ type: 'checkbox', payload: e.target })
    }

    const onAppChange = (e) => {
        console.log('---e--', e);
        dispatch({ type: 'input', payload: { name: 'application', value: e.value } })
    }

    const addUser = async () => {
        console.log('----state ---', state);
        const user = await addNewUser({
            name: state.name,
            email: state.email,
            password: state.password,
            sysadmin: state.sysadmin,
            normal: state.normal,
            application: state.application
        });

        if (user.data) {
            dispatch2({ type: 'USER_ADDED_SUCCESSFULLY', payload: user.data })
        } else {
            dispatch2({ type: 'USER_NOT_ADDED', payload: user.error })
        }
        console.log('---user created --', user);
    }

    const validatePassword = (e) => {
        console.log('--e---', e.target.value);
        if (state.password !== state.cnfrmpassword) {
            console.log('---Password does not match ----');
            dispatch({ type: 'error', payload: { name: 'cnfrmpassword', value: 'Password does not match' } });
            dispatch({ type: 'cssclass', payload: { name: e.target.name, value: true } })
        }
        else {
            dispatch({ type: 'cssclass', payload: { name: e.target.name, value: false } })
        }

    }

    const getMessage = () => {

        if (state2.message === undefined) {
            return <span></span>
        }
        if (state2.message !== '' && state2.success) {
            return <div className="alert alert-success mt-4" role="alert">
                {state2.message}
            </div>

        } else if (state2.message === '') {
            return <span></span>
        } else {
            console.log('---state2---', state2);
            return <div className="alert alert-danger mt-4" role="alert">
                {state2.message}
            </div>
        }
    }

    return (
        <div>
            <NavBar stylename="prodlayout" />
            <div className="container" style={{ 'background': '#fff', 'marginTop': '20px', 'padding': '20px' }}>
            <div className="row basemargin">
                    <Typography variant="h6" gutterBottom style={{ 'marginLeft': '13px' }}>Add user</Typography>
                </div>
                
                    {getMessage()}
               
                
                <div className="row basemargin">
                    <div className="col-2" style={{ 'textAlign': 'right' }}> <label htmlFor="name">Name</label></div>
                    <div className="col-8">
                        <input type="text" placeholder="Enter Name" name="name" className="col-12" onChange={onChange} />
                    </div>
                </div>

                <div className="row basemargin">
                    <div className="col-2" style={{ 'textAlign': 'right' }}>
                        <label htmlFor="email">Email</label>
                    </div>
                    <div className="col-8">
                        <input type="email" placeholder="Enter Email" name="email" className="col-12" onChange={onChange} />
                    </div>
                </div>
                <div className="row basemargin">
                    <div className="col-2" style={{ 'textAlign': 'right' }}>
                        <label htmlFor="password">Password</label>
                    </div>
                    <div className="col-8">
                        <input type="password" placeholder="Enter Password" name="password" className="col-12" onChange={onChange} />
                    </div>
                </div>
                <div className="row basemargin">
                    <div className="col-2" style={{ 'textAlign': 'right' }}>
                        <label htmlFor="cnfrmpassword">Confirm Password</label>
                    </div>
                    <div className="col-8">
                        <input type="password" placeholder="Enter Password" name="cnfrmpassword"
                            className={state.cssclass && state.cssclass.cnfrmpassword ? 'col-12 border border-danger' : 'col-12 '}
                            onChange={onChange}
                            onBlur={validatePassword} />
                    </div>
                </div>
                <div className="row basemargin">
                    <div className="col-2" style={{ 'textAlign': 'right' }}>
                        <label htmlFor="application"> Applications</label>
                    </div>
                    {state1.loading ? <div className="col-8">Loading...</div> :
                        <div className="col-8">
                            <Select name="application" options={state1.applications} onChange={onAppChange} />
                        </div> 
                    }
                </div>
                <div className="row basemargin">
                    <div className="col-2" style={{ 'textAlign': 'right' }}>
                        <label htmlFor="sysadmin">System Admin</label>
                    </div>
                    <div className="col-8">
                        <input type="checkbox" name="sysadmin" onChange={onChangeInput} />
                    </div>
                </div>
                <div className="row basemargin">
                    <div className="col-2" style={{ 'textAlign': 'right' }}>
                        <label htmlFor="normal"> Admin</label>
                    </div>
                    <div className="col-8">
                        <input type="checkbox" name="normal" onChange={onChangeInput} />
                    </div>
                </div>

                <div className="row basemargin">
                    <div className="col-2" style={{ 'textAlign': 'right' }}></div>
                    <div className="col-8">
                        <button className="btn btn-primary" onClick={addUser}>Add User</button>
                    </div>

                </div>
            </div>
        </div>
    )
}

export default UserPage;