import React from 'react';
import MenuMolecule from './MenuMolecule';


export default function MenuBarForSystemAdmin() {

  return (
    <div>
        <MenuMolecule 
               menuName="Onboarding" 
               items= {['App Setup', 'Vault Setup']} />
    </div>
  );
}
