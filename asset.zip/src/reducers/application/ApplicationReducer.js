
export const ApplicationReducer = (state, action) => {
    console.log('---action ----', action);
    switch (action.type) {
        case 'LOADING':
            return {
                ...state,
                loading: true
            }
        case 'LOADED':
            return {
                ...state,
               loading: false,
               applications: action.payload
            }   
        default:
            return state;
    }
}