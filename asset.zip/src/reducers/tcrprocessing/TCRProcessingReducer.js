export const tcrProcessingMessages = [];
let seq = 0;
export const TCRProcessingReducer = (state, action ) => {
    console.log('----TCRProcessingReducer ----',state);
    console.log('----TCRProcessingReducer ----',action);
    switch (action.type) {
        case 'tcrProcessing':
            seq = seq+1;
            return [...state, {...action.payload,seq: seq}];            
        case 'cleanup':
            seq = 0;
            return [];    
    
        default:
            return state;
    }
}