
export const userInitialState = {
    name: '',
    email: '',
    sysadmin: false,
    normal: false,
    cnfrmpassword:'',
    password: '',
    errors: [],
    getClass:"col-10 "
}



export const UserReducer = (state, action) => {
    switch (action.type) {
        case 'input':
            return {
                ...state,
                [action.payload.name]: action.payload.value
            }
        case 'checkbox':
            return {
                ...state,
                [action.payload.name]: action.payload.checked
            }
        case 'error':
            return {
                ...state,
                errors:[...state.errors, {[action.payload.name]: action.payload.value}]
            }   
        case 'cssclass': 
            return {
                ...state,
                cssclass: {...state.cssclass,[action.payload.name]:action.payload.value}
            } 

        case 'reset':
                    return userInitialState;
        default:
            return state;
    }
}

export const UserCreationReducer = (state, action) => {
    switch(action.type){
        case 'USER_ADDED_SUCCESSFULLY':
            return {
               message: action.payload.message,
               success: true
            }
        case 'USER_NOT_ADDED': 
           return {
             message: action.payload,
             success: false
           }
        default:
            return {
                message: '',
                success: false
            }
    }
}