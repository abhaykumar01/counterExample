import React from 'react';

import { Switch, Route, Redirect } from 'react-router-dom';
import NonProdLayout from '../components/layout/NonProdLayout';
import ProdLayout from '../components/layout/ProdLayout';
import FileUpload from '../components/fileupload/FileUpload';
import Login from '../components/login/Login';
import Auth from '../auth/Auth';
import UserPage from '../components/user/UserPage';
import ChangePassword from '../components/login/ChangePassword';
import PrivateRoute from './PrivateRoute';
import AuditComponent from '../components/audit/AuditComponent';

const AppRoutes = (props) => {
    return (
        <Switch>
            <Route data-testid="home" path='/' exact render={(routerProps) => <Login {...props} {...routerProps} />} />
            <PrivateRoute path='/nonprod' exact component={NonProdLayout } />
            <PrivateRoute path='/prod' exact component={ProdLayout} />
            <PrivateRoute path='/fileupload' exact component={FileUpload} />
            <PrivateRoute path='/user' exact component={UserPage} />
            <Route path='/logout' exact render={(routerProps) => <Logout {...props} {...routerProps} />} />
            <PrivateRoute path='/changepassword' exact component={ChangePassword} />
            <PrivateRoute path='/audit' exact component={AuditComponent} />
            <Redirect to='/' />
        </Switch>
    )
}

export default AppRoutes;

const Logout = (props) => {
    Auth.deauthenticateUser();
    props.history.push('/');
    return <div></div>
}