import http from  './common';

export const getTCRDetails = async (tcrno,env,action) => {

  try{
      const uristring = `/servicenow/${tcrno}`;
     
      const data  = await http.get(uristring)
      console.log('---data----',data);
      return data;
    }catch(error) {
     console.error('Error in fetching TCR Details', error.response);
     return {error: error.response}
  }
}

export const authenticate = async (username, password) => {
  try{
      const uristring = `/login`;
     
      const data  = await http.post(uristring,{
        username: username,
        password: password
      })
      console.log('---data----',data);
      return data;
    }catch(error) {
     console.log('Invalid Login', error);
    //  console.log('---type ---', typeof(error));
    //  console.log('--string form ---', error.toString());
    if(error.response){
      console.log('--Error while validating login ---',error.response);
      return {error: error.response}
    }
     else if(error.toString().includes('Network Error')){
       console.log('---Network Error ---');
       return {error: {data: 'Please check the server may be down'}};
     }
     return {error: error.response}
  }
}

export const svncheckout = async (repo,tcrNo, env, action, responses, curtime, records, app) => {
  try{
      const uristring = `/svncheckout/`;
     
      const data  = await http.post(uristring, {
        repo: repo,
        tcrno: tcrNo, 
        env, 
        action, 
        responses, 
        curtime, 
        records,
        app
      })
      console.log('---data----',data);
      return data;
    }catch(error) {
     console.error('Error during checkout :', error);
     return {error: error.response}
  }
}

export const executeAnsibleTasks = async (srcsys, svnrepo, tcrno, action, env, curtime, tag, app, isEnvChecked, srcrevision) => {
  try{
     const uristring = `/executeAnsibletags`;

     console.log("---ServiceNow.js executetage ---",uristring, srcsys, svnrepo, tcrno, action, env, curtime, tag, app, isEnvChecked, srcrevision);
     const data = await http.post(uristring,{ 
      srcsys: srcsys,
      svnrepo: svnrepo, 
      tcrno: tcrno, 
      action: action, 
      env: env,
      curtime: curtime, 
      tag: tag,
      app: app,
      isEnvChecked: isEnvChecked,
      srcrevision: srcrevision
    }, {timeout: 30000});
     console.log('-executeAnsibleTasks--data------',data);
     return data;
  }catch(error) {
    console.error('executeAnsibleTasks() - Issue executing ansible tasks: ', error);
    return {error: error}
  }
}

export const fetchAnsibleTags = async (sys, tcrno, curtime, action,srctype, env) => {
  console.log('---fetchAnsibleTags---',sys,  tcrno, curtime, action,srctype, env);
 
  try{
     const uristring = `/fetchAnsibleTags`;
     const data = await http.post(uristring, {
        sys,
        tcrno,
        curtime,
        action,
        srctype,
        env
     });
     console.log('-executeAnsibleTasks--data------',data);
     return data;
  }catch(error) {
    console.error('fetchAnsibleTags() - Issue fetching ansible tags: ', error.response);
    return {error: error.response}
  }
}

export const getTCRData = async (tcrno, env, action ,application) => {
	try{
	const uristring = `/param`;

	const data = await http.post(uristring,{
		tcrno: tcrno,
		env: env,
    action: action,
    application
	})
	console.log('-------data----------',data);
	return data;
	}
	catch(error) {
	console.error('No data provided', error.response);
	return {error: error.response}
}
}

export const getApplications = async (username) => {
  try {
    const uristring = `/applications/${username}`;
    const data = await http.get(uristring);
    console.log('---data----',data);
    return data;
  }catch(error) {
   console.error('Error in fetching Application Details', error.response);
   return {error: error.response}
}
}
	

