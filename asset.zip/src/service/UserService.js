import http from  './common';

export const addNewUser = async (user) => {

  try{
      const uristring = `/users/`;
     
      const data  = await http.post(uristring , {
          user: user
      })
      console.log('---User Created----',data);
      return data;
    }catch(error) {
     console.error('Error in Creating New User', error.response);
     return {error: error.response}
  }
}

export const changePassword = async (user) => {

    try{
        const uristring = `/users/changepassword`;
       
        const data  = await http.post(uristring , {
            user: user
        })
        console.log('---Password Changed----',data);
        return data;
      }catch(error) {
       console.error('Error in Changing Password', error.response);
       return {error: error.response}
    }
  }

export const getAllApplications = async () => {
    try{
        const uristring= '/applications';
        const data = await http.get(uristring);
        console.log('----getAllApplications---',data);
        return data;
    }catch(error) {
        console.error('Error in fetching list of applications ', error);
        
    }
}

export const getEnvironmentsForApplication = async (app) => {
    try{
        const data = await http.get(`/environments/${app}`);
        console.log('----environments for app ', data);
        return data;
    }catch(error) {
        console.error('Error in fetching list of environments ',error);
    }
}
 
