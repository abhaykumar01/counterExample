import axios from 'axios';
import Auth from '../auth/Auth';

const http = axios.create({
    baseURL: `http://${process.env.REACT_APP_SERVER}:5000/`,
    timeout: 10000,
    headers: {'Content-Type':'application/json' }
});

http.interceptors.request.use(
    function(config) {
        const token = Auth.getToken();
        // console.log('----token ---',token);
        if(token) {
            config.headers.Authorization = `Bearer ${token}`;
            config.headers.sysid = Auth.getUserSysId();
            config.headers.email = Auth.getDecodedToken();
        }   
        return config;
    },
    function (error) {
        console.log('---error in request interceptor----',error);
        return Promise.reject (error);
    }
);

// axios.interceptors.response.use(function (response) {
//     // Any status code that lie within the range of 2xx cause this function to trigger
//     // Do something with response data
//     return response;
//   }, function (error) {
//     // Any status codes that falls outside the range of 2xx cause this function to trigger
//     // Do something with response error
//     if (!error.response) {
//         console.log("Please check your internet connection.");
//     }

//     console.log('----error in interceptors -----',error);
//     return Promise.reject(error);
//   });

export default http;