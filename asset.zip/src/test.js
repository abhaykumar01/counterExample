const myArray = [
    {message: 'Message1', error: [], tcr: 'tcrno'},
    {message: 'Message2', error: [], tcr: 'tcrno'},
    {message: '', error: ['Error1'], tcr: 'tcrno'}
]

const mod = myArray.map((item,i) => {
    if(item.error.length > 0){
        return {error: item.error}
    }
    else 
      return {message: item.message}
});

console.log('---mod---', mod);