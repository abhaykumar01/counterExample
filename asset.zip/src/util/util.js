import moment from 'moment';

export const checkDateBetween = (start_date, end_date) => {
    console.log('---checkDateBetween ',start_date, end_date);
   const isBetween = moment().isBetween(start_date, end_date);
   
   console.log(isBetween);
   console.log('--current ---', moment());
   return isBetween;
}